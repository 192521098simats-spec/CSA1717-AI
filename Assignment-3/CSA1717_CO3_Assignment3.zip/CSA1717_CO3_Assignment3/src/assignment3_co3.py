#!/usr/bin/env python3
"""
CSA1717 - Artificial Intelligence - Assignment 3 (CO3)
Logical agents, propositional/first-order inference, unification, resolution,
forward/backward chaining and a knowledge-based design challenge.

Single reproducible source file.  Usage:
    python src/assignment3_co3.py --out results            (all tasks)
    python src/assignment3_co3.py --out results --only 1 4 (selected tasks)

Operation counts (models, clauses, unifications, goals, steps) are the primary
evidence; wall-clock time is secondary.  Fixed seeds are used throughout.
"""
import argparse, itertools, json, math, os, random, sys, time, tracemalloc
from collections import defaultdict, deque

sys.setrecursionlimit(50000)
RESULTS = {}

def now(): return time.perf_counter()

# =====================================================================
# 0. PROPOSITIONAL LOGIC LIBRARY (expressions, CNF, truth tables)
# =====================================================================
def S(n):            return ('s', n)
def Not(a):          return ('not', a)
def And(*a):         return ('and',) + tuple(a)
def Or(*a):          return ('or',) + tuple(a)
def Imp(a, b):       return ('imp', a, b)
def Iff(a, b):       return ('iff', a, b)
TRUE, FALSE = ('true',), ('false',)

def symbols_of(e, acc=None):
    acc = set() if acc is None else acc
    if e[0] == 's': acc.add(e[1])
    elif e[0] in ('true', 'false'): pass
    else:
        for x in e[1:]: symbols_of(x, acc)
    return acc

def show(e):
    t = e[0]
    if t == 's': return e[1]
    if t == 'true': return 'T'
    if t == 'false': return 'F'
    if t == 'not': return '~' + show(e[1])
    if t == 'and': return '(' + ' & '.join(show(x) for x in e[1:]) + ')'
    if t == 'or':  return '(' + ' | '.join(show(x) for x in e[1:]) + ')'
    if t == 'imp': return '(' + show(e[1]) + ' => ' + show(e[2]) + ')'
    if t == 'iff': return '(' + show(e[1]) + ' <=> ' + show(e[2]) + ')'

def eval_expr(e, m):
    t = e[0]
    if t == 's': return m[e[1]]
    if t == 'true': return True
    if t == 'false': return False
    if t == 'not': return not eval_expr(e[1], m)
    if t == 'and': return all(eval_expr(x, m) for x in e[1:])
    if t == 'or':  return any(eval_expr(x, m) for x in e[1:])
    if t == 'imp': return (not eval_expr(e[1], m)) or eval_expr(e[2], m)
    if t == 'iff': return eval_expr(e[1], m) == eval_expr(e[2], m)

def compile_expr(e, idx):
    """Compile an expression into a Python function of an integer bit-mask."""
    def src(x):
        t = x[0]
        if t == 's':   return '((b>>%d)&1)' % idx[x[1]]
        if t == 'true': return 'True'
        if t == 'false': return 'False'
        if t == 'not': return '(not %s)' % src(x[1])
        if t == 'and': return '(' + ' and '.join(src(y) for y in x[1:]) + ')'
        if t == 'or':  return '(' + ' or '.join(src(y) for y in x[1:]) + ')'
        if t == 'imp': return '((not %s) or %s)' % (src(x[1]), src(x[2]))
        if t == 'iff': return '(bool(%s) == bool(%s))' % (src(x[1]), src(x[2]))
    return eval('lambda b: bool(%s)' % src(e))

def tt_entails(kb, alpha, symbols=None):
    """Truth-table entailment.  Enumerates ALL 2^m models (no early exit on
    models) so that the model count is deterministic.  Returns a dict."""
    syms = sorted(symbols if symbols is not None else
                  set().union(*[symbols_of(s) for s in kb], symbols_of(alpha)))
    idx = {s: i for i, s in enumerate(syms)}
    kbf = [compile_expr(s, idx) for s in kb]
    af = compile_expr(alpha, idx)
    m = len(syms)
    kb_models = a_true = sent_evals = 0
    t0 = now()
    for b in range(1 << m):
        ok = True
        for f in kbf:
            sent_evals += 1
            if not f(b): ok = False; break
        if ok:
            kb_models += 1
            if af(b): a_true += 1
    dt = now() - t0
    if kb_models == 0: verdict = 'KB inconsistent'
    elif a_true == kb_models: verdict = 'entailed'
    elif a_true == 0: verdict = 'negation entailed'
    else: verdict = 'neither entailed'
    return dict(symbols=m, models_enumerated=1 << m, kb_models=kb_models,
                alpha_true_in_kb_models=a_true, sentence_evals=sent_evals,
                time_ms=round(dt * 1000, 2), verdict=verdict)

# ---- CNF conversion -------------------------------------------------
def elim(e):
    t = e[0]
    if t in ('s', 'true', 'false'): return e
    if t == 'not': return Not(elim(e[1]))
    if t in ('and', 'or'): return (t,) + tuple(elim(x) for x in e[1:])
    a, b = elim(e[1]), elim(e[2])
    if t == 'imp': return Or(Not(a), b)
    if t == 'iff': return And(Or(Not(a), b), Or(Not(b), a))

def nnf(e, neg=False):
    t = e[0]
    if t == 's':   return Not(e) if neg else e
    if t == 'true':  return FALSE if neg else TRUE
    if t == 'false': return TRUE if neg else FALSE
    if t == 'not': return nnf(e[1], not neg)
    if t == 'and': return (Or if neg else And)(*[nnf(x, neg) for x in e[1:]])
    if t == 'or':  return (And if neg else Or)(*[nnf(x, neg) for x in e[1:]])

def lit_of(e): return ('~' + e[1][1]) if e[0] == 'not' else e[1]
def neg_lit(l): return l[1:] if l[0] == '~' else '~' + l
def is_taut(c): return any(neg_lit(l) in c for l in c)

def cnf_clauses(e):
    """Return list of frozenset-clauses (literal strings, '~' prefix = negation)."""
    e = nnf(elim(e))
    def conv(x):
        t = x[0]
        if t in ('s', 'not'): return [frozenset([lit_of(x)])]
        if t == 'true': return []
        if t == 'false': return [frozenset()]
        if t == 'and': return [c for y in x[1:] for c in conv(y)]
        if t == 'or':
            parts = [conv(y) for y in x[1:]]
            res = [frozenset()]
            for p in parts:
                res = [a | b for a in res for b in p]
            return res
    out = []
    for c in conv(e):
        if not is_taut(c) and c not in out: out.append(c)
    return out

def check_cnf_equivalent(e):
    """Verify by truth table that the CNF of e is logically equivalent to e."""
    cls = cnf_clauses(e)
    syms = sorted(symbols_of(e))
    for vals in itertools.product([False, True], repeat=len(syms)):
        m = dict(zip(syms, vals))
        c = all(any((not m[l[1:]]) if l[0] == '~' else m[l] for l in cl) for cl in cls)
        if c != eval_expr(e, m): return False
    return True

# ---- Propositional resolution (given-clause loop, instrumented) ------
def resolution_refute(clauses, max_generated=200000, keep_proof=True):
    stats = dict(input_clauses=0, generated=0, resolvents_attempted=0,
                 tautologies_discarded=0, subsumed_removed=0, max_active=0)
    t0 = now()
    seen = set(); passive = deque(); parents = {}
    for c in clauses:
        c = frozenset(c)
        if is_taut(c): stats['tautologies_discarded'] += 1; continue
        if c in seen: continue
        seen.add(c); passive.append(c); parents[c] = None
    stats['input_clauses'] = len(passive)
    active = set(); index = defaultdict(set)
    empty = frozenset() if frozenset() in seen else None
    def add_active(c):
        active.add(c)
        for l in c: index[l].add(c)
    def rem_active(c):
        active.discard(c)
        for l in c: index[l].discard(c)
    def subsumed_by_active(c):
        for l in c:
            for d in index[l]:
                if d <= c: return True
        return False
    while passive and empty is None and stats['generated'] < max_generated:
        g = passive.popleft()
        if subsumed_by_active(g): stats['subsumed_removed'] += 1; continue
        cands = set()
        for l in g: cands |= index[l]
        for d in cands:
            if g < d: rem_active(d); stats['subsumed_removed'] += 1
        add_active(g)
        stats['max_active'] = max(stats['max_active'], len(active))
        for l in list(g):
            for d in list(index[neg_lit(l)]):
                stats['resolvents_attempted'] += 1
                r = frozenset((g - {l}) | (d - {neg_lit(l)}))
                if is_taut(r): stats['tautologies_discarded'] += 1; continue
                if r in seen: continue
                seen.add(r); stats['generated'] += 1
                parents[r] = (g, d)
                if not r: empty = r; break
                passive.append(r)
            if empty is not None: break
    stats['time_ms'] = round((now() - t0) * 1000, 2)
    stats['refuted'] = empty is not None
    stats['hit_cap'] = (empty is None and bool(passive))
    proof = None
    if empty is not None and keep_proof:
        order, vis = [], set()
        def walk(c):
            if c in vis: return
            vis.add(c)
            if parents.get(c):
                walk(parents[c][0]); walk(parents[c][1])
            order.append(c)
        walk(empty)
        proof = [(sorted(c), None if parents[c] is None else (sorted(parents[c][0]), sorted(parents[c][1]))) for c in order]
        stats['proof_length'] = sum(1 for p in proof if p[1] is not None)
    return stats, proof

def fmt_clause(c): return '{' + ', '.join(c) + '}' if c else '{} (empty)'


# =====================================================================
# TASK 1 - Wumpus-world KB, model checking and inference rules
# =====================================================================
def nbrs(x, y, n):
    return [(a, b) for a, b in ((x+1, y), (x-1, y), (x, y+1), (x, y-1)) if 1 <= a <= n and 1 <= b <= n]
def P(x, y): return S('P%d%d' % (x, y))
def W(x, y): return S('W%d%d' % (x, y))
def B(x, y): return S('B%d%d' % (x, y))
def St(x, y): return S('S%d%d' % (x, y))

def wumpus_kb(n):
    """General rules of the n x n Wumpus world (percept sentences excluded)."""
    kb = [Not(P(1, 1)), Not(W(1, 1))]
    sq = [(x, y) for x in range(1, n+1) for y in range(1, n+1)]
    for (x, y) in sq:
        ps = [P(a, b) for a, b in nbrs(x, y, n)]
        ws = [W(a, b) for a, b in nbrs(x, y, n)]
        kb.append(Iff(B(x, y), ps[0] if len(ps) == 1 else Or(*ps)))
        kb.append(Iff(St(x, y), ws[0] if len(ws) == 1 else Or(*ws)))
    kb.append(Or(*[W(x, y) for (x, y) in sq]))
    for a, b in itertools.combinations(sq, 2):
        kb.append(Or(Not(W(*a)), Not(W(*b))))
    return kb

def wumpus_counts(n):
    sq = n * n
    return dict(n=n, symbols=4*sq, sentences=2 + 2*sq + 1 + sq*(sq-1)//2,
                breeze_stench_rules=2*sq, at_most_one=sq*(sq-1)//2,
                models_log10=round(4*sq*math.log10(2), 2))

def percept_sentences(percepts):
    out = []
    for (x, y, br, st) in percepts:
        out.append(B(x, y) if br else Not(B(x, y)))
        out.append(St(x, y) if st else Not(St(x, y)))
    return out

def restricted_kb(n, percepts, query_sq):
    """Relevant-symbol KB: only visited squares, their neighbours and the query
    square; percept truth values substituted into the local rules."""
    vis = [(x, y) for (x, y, _, _) in percepts]
    rel = set(vis) | {s for v in vis for s in nbrs(*v, n)} | {query_sq}
    kb = [Not(P(1, 1)), Not(W(1, 1))]
    for (x, y, br, st) in percepts:
        ps = [P(a, b) for a, b in nbrs(x, y, n)]
        ws = [W(a, b) for a, b in nbrs(x, y, n)]
        kb.append((Or(*ps) if len(ps) > 1 else ps[0]) if br else And(*[Not(p) for p in ps]))
        kb.append((Or(*ws) if len(ws) > 1 else ws[0]) if st else And(*[Not(w) for w in ws]))
    rs = sorted(rel)
    for a, b in itertools.combinations(rs, 2):
        kb.append(Or(Not(W(*a)), Not(W(*b))))
    syms = set()
    for (x, y) in rs: syms |= {'P%d%d' % (x, y), 'W%d%d' % (x, y)}
    return kb, syms

SCEN_SMALL = [(1, 1, False, False)]
SCEN_STD = [(1, 1, False, False), (2, 1, True, False), (1, 2, False, True)]

def task1_partA():
    out = {'counts': [wumpus_counts(n) for n in (2, 3, 4, 5, 6)], 'runs': []}
    # ---- n = 2 : full symbol set, scenario SMALL
    kb2 = wumpus_kb(2) + percept_sentences(SCEN_SMALL)
    q2 = {'Q1 entailed: [1,2] safe': And(Not(P(1, 2)), Not(W(1, 2))),
          'Q2 negation entailed: pit at [1,2]': P(1, 2),
          'Q3 neither: pit at [2,2]': P(2, 2)}
    rate = None
    for name, a in q2.items():
        r = tt_entails(kb2, a)                      # full: 4n^2 = 16 symbols
        r.update(n=2, mode='full symbols', query=name)
        out['runs'].append(r); rate = r['models_enumerated'] / max(r['time_ms'], 1e-3) * 1000
        sq = (1, 2) if 'pit at [1,2]' in name or '[1,2]' in name else (2, 2)
        kbr, sy = restricted_kb(2, SCEN_SMALL, sq)
        r2 = tt_entails(kbr, a, symbols=sy); r2.update(n=2, mode='relevant symbols', query=name)
        out['runs'].append(r2)
    # ---- n = 3, 4 : scenario STD
    for n in (3, 4):
        qs = {'Q1 entailed: [2,2] safe': (And(Not(P(2, 2)), Not(W(2, 2))), (2, 2)),
              'Q2 negation entailed: pit at [2,2]': (P(2, 2), (2, 2)),
              'Q3 neither: pit at [3,2]': (P(3, 2), (3, 2)),
              'Q4 entailed: pit at [3,1]': (P(3, 1), (3, 1))}
        for name, (a, sq) in qs.items():
            kbr, sy = restricted_kb(n, SCEN_STD, sq)
            r = tt_entails(kbr, a, symbols=sy); r.update(n=n, mode='relevant symbols', query=name)
            out['runs'].append(r)
        m = 4 * n * n
        out['runs'].append(dict(n=n, mode='full symbols', query='any', symbols=m,
            models_enumerated=2**m, time_ms=None, verdict='infeasible',
            projected_seconds=round(2**m / rate, 1), projected_years=round(2**m / rate / 31557600, 3)))
    out['throughput_models_per_s'] = round(rate)
    return out

# ---- Part B: inference-rule derivation -------------------------------
class Derivation:
    """Tracks a derivation; each rule application is checked for soundness by
    verifying (premises => conclusion) over the 12 relevant symbols."""
    def __init__(self, syms, kb):
        self.steps = []; self.counts = defaultdict(int); self.known = []
        self.syms = sorted(syms); self.kb = kb
    def _check(self, prem, concl):
        syms = sorted(set().union(*[symbols_of(x) for x in prem], symbols_of(concl)))
        for vals in itertools.product([False, True], repeat=len(syms)):
            m = dict(zip(syms, vals))
            if all(eval_expr(p, m) for p in prem) and not eval_expr(concl, m):
                raise AssertionError('unsound step: ' + show(concl))
    def add(self, rule, prem, concl, kind='inference'):
        self._check(prem, concl)
        self.counts[rule] += 1
        self.steps.append(dict(n=len(self.steps)+1, rule=rule, kind=kind,
                               premises=[show(p) for p in prem], conclusion=show(concl)))
        return concl
    def and_elim(self, conj, i):
        return self.add('And-Elimination', [conj], conj[1+i])
    def mp(self, imp, ante):
        assert imp[0] == 'imp' and imp[1] == ante
        return self.add('Modus Ponens', [imp, ante], imp[2])
    def unit_res(self, disj, lit_neg):
        # disj = Or(a,b,..), lit_neg = literal whose complement is in disj
        comp = lit_neg[1] if lit_neg[0] == 'not' else Not(lit_neg)
        rest = [x for x in disj[1:] if x != comp]
        assert len(rest) == len(disj) - 2 + (0 if comp in disj[1:] else 1)
        concl = rest[0] if len(rest) == 1 else Or(*rest)
        return self.add('Unit Resolution', [disj, lit_neg], concl)
    def rewrite(self, name, src, concl):          # equivalence rewrite (sound, not counted as inference rule)
        return self.add(name, [src], concl, kind='rewrite')

def task1_partB():
    n = 3
    kbr, sy = restricted_kb(n, SCEN_STD, (2, 2))
    d = Derivation(sy, kbr)
    # percept conjunctions (sentences in the KB after perceiving)
    c11 = And(Not(B(1, 1)), Not(St(1, 1)))
    c21 = And(B(2, 1), Not(St(2, 1)))
    c12 = And(Not(B(1, 2)), St(1, 2))
    # local rules, as obtained from  B <=> (P ...)  by biconditional elimination
    # (equivalence rewrite) -- the KB is already stored in the instantiated form below.
    # --- square [2,2]: derive ~P22 from  ~B12  and  B12 <=> (P11 | P22 | P13)
    notB12 = d.and_elim(c12, 0)                       # AE
    S12 = d.and_elim(c12, 1)                          # AE
    iff_b12 = Iff(B(1, 2), Or(P(1, 1), P(2, 2), P(1, 3)))
    rhs_to_b = d.rewrite('Biconditional elimination', iff_b12, Imp(Or(P(1, 1), P(2, 2), P(1, 3)), B(1, 2)))
    contra = d.rewrite('Contraposition', rhs_to_b, Imp(Not(B(1, 2)), Not(Or(P(1, 1), P(2, 2), P(1, 3)))))
    nor = d.mp(contra, notB12)                        # MP
    conj_np = d.rewrite("De Morgan", nor, And(Not(P(1, 1)), Not(P(2, 2)), Not(P(1, 3))))
    notP22 = d.and_elim(conj_np, 1)                   # AE
    notP13 = d.and_elim(conj_np, 2)                   # AE
    # --- ~W22 from ~S21 and  S21 <=> (W11 | W22 | W31)
    notS21 = d.and_elim(c21, 1)                       # AE
    B21 = d.and_elim(c21, 0)                          # AE
    iff_s21 = Iff(St(2, 1), Or(W(1, 1), W(2, 2), W(3, 1)))
    rhs_to_s = d.rewrite('Biconditional elimination', iff_s21, Imp(Or(W(1, 1), W(2, 2), W(3, 1)), St(2, 1)))
    contra_s = d.rewrite('Contraposition', rhs_to_s, Imp(Not(St(2, 1)), Not(Or(W(1, 1), W(2, 2), W(3, 1)))))
    nor_s = d.mp(contra_s, notS21)                    # MP
    conj_nw = d.rewrite('De Morgan', nor_s, And(Not(W(1, 1)), Not(W(2, 2)), Not(W(3, 1))))
    notW22 = d.and_elim(conj_nw, 1)                   # AE
    notW11 = d.and_elim(conj_nw, 0)                   # AE
    safe22 = d.add('And-Introduction', [notP22, notW22], And(notP22, notW22), kind='rewrite')
    steps_safe22 = len(d.steps); counts22 = dict(d.counts)
    inf22 = sum(1 for s in d.steps if s['kind'] == 'inference')
    # --- square [1,3]: ~P13 already derived; W13 from  S12 <=> (W11|W22|W13)
    d.counts = defaultdict(int); mark = len(d.steps)
    iff_s12 = Iff(St(1, 2), Or(W(1, 1), W(2, 2), W(1, 3)))
    s12_to = d.rewrite('Biconditional elimination', iff_s12, Imp(St(1, 2), Or(W(1, 1), W(2, 2), W(1, 3))))
    disj = d.mp(s12_to, S12)                          # MP
    r1 = d.unit_res(disj, notW11)                     # UR  -> (W22 | W13)
    w13 = d.unit_res(r1, notW22)                      # UR  -> W13
    inf_w13 = sum(1 for s_ in d.steps if s_['kind'] == 'inference') - inf22
    # --- pit at [3,1] from B21 and  B21 <=> (P11|P22|P31)
    iff_b21 = Iff(B(2, 1), Or(P(1, 1), P(2, 2), P(3, 1)))
    b21_to = d.rewrite('Biconditional elimination', iff_b21, Imp(B(2, 1), Or(P(1, 1), P(2, 2), P(3, 1))))
    dj = d.mp(b21_to, B21)                            # MP
    u1 = d.unit_res(dj, Not(P(1, 1)))                 # UR (needs ~P11, a fact in KB)
    p31 = d.unit_res(u1, notP22)                      # UR
    inf_total = sum(1 for s in d.steps if s['kind'] == 'inference')
    inf13 = inf_w13
    # model-checking cost for the same two queries (relevant symbols, 12 symbols)
    mc22 = tt_entails(kbr, And(Not(P(2, 2)), Not(W(2, 2))), symbols=sy)
    kb13, sy13 = restricted_kb(3, SCEN_STD, (1, 3))
    mc13 = tt_entails(kb13, And(Not(P(1, 3)), Not(W(1, 3))), symbols=sy13)
    # soundness tables
    def table(name, f_prem, f_concl, vars_):
        rows = []
        for vals in itertools.product([False, True], repeat=len(vars_)):
            m = dict(zip(vars_, vals))
            rows.append(dict(zip(vars_, vals), prem=f_prem(m), concl=f_concl(m)))
        sound = all((not r['prem']) or r['concl'] for r in rows)
        return dict(rule=name, vars=vars_, rows=rows, sound=sound)
    tables = [
        table('Modus Ponens: a, a=>b |- b', lambda m: m['a'] and ((not m['a']) or m['b']), lambda m: m['b'], ['a', 'b']),
        table('And-Elimination: a&b |- a', lambda m: m['a'] and m['b'], lambda m: m['a'], ['a', 'b']),
        table('Unit Resolution: a|b, ~a |- b', lambda m: (m['a'] or m['b']) and (not m['a']), lambda m: m['b'], ['a', 'b']),
    ]
    pit31_steps = inf_total - inf22 - inf_w13
    return dict(steps=d.steps, pit31_inference_steps=pit31_steps, safe22_steps_total=steps_safe22, safe22_inference_steps=inf22,
                safe22_rule_counts=counts22, unsafe13_inference_steps=inf13,
                total_inference_steps=inf_total, total_steps_incl_rewrites=len(d.steps),
                mc_safe22=mc22, mc_safe13=mc13, soundness_tables=tables,
                derived=dict(safe22=show(safe22), W13=show(w13), P31=show(p31), notP13=show(notP13)))

def task1():
    A = task1_partA(); Bp = task1_partB()
    return dict(partA=A, partB=Bp)



# =====================================================================
# TASK 2 - Model checking versus propositional resolution
# =====================================================================
def policy_kb():
    """Smart-building access-control policy (13 rules: implication,
    biconditional and disjunction).  Symbols: Bv badge valid, St staff,
    Vi visitor, Es escorted, Ho business hours, Em emergency, Np night pass,
    Rs restricted area, Ac access granted, Un door unlocked, Lg access logged."""
    s = {k: S(k) for k in 'Bv St Vi Es Ho Em Np Rs Ac Un Lg'.split()}
    R = [
        ('R1  staff with valid badge in business hours -> access', Imp(And(s['Bv'], s['St'], s['Ho']), s['Ac'])),
        ('R2  night pass + staff + valid badge -> access',        Imp(And(s['Np'], s['St'], s['Bv']), s['Ac'])),
        ('R3  visitor, escorted, valid badge -> access',          Imp(And(s['Vi'], s['Es'], s['Bv']), s['Ac'])),
        ('R4  emergency override -> access',                      Imp(s['Em'], s['Ac'])),
        ('R5  staff <=> not visitor',                             Iff(s['St'], Not(s['Vi']))),
        ('R6  door unlocked <=> access granted',                  Iff(s['Un'], s['Ac'])),
        ('R7  access logged <=> access granted',                  Iff(s['Lg'], s['Ac'])),
        ('R8  access for a visitor requires escort or emergency', Imp(And(s['Ac'], s['Vi']), Or(s['Es'], s['Em']))),
        ('R9  restricted area access requires (staff and badge) or emergency',
                                                                  Imp(And(s['Ac'], s['Rs']), Or(And(s['St'], s['Bv']), s['Em']))),
        ('R10 no badge and no emergency -> no access',            Imp(And(Not(s['Bv']), Not(s['Em'])), Not(s['Ac']))),
        ('R11 staff outside hours without night pass or emergency -> no access',
                                                                  Imp(And(s['St'], Not(s['Ho']), Not(s['Np']), Not(s['Em'])), Not(s['Ac']))),
        ('R12 visitor in restricted area without emergency -> no access', Imp(And(s['Vi'], s['Rs'], Not(s['Em'])), Not(s['Ac']))),
        ('R13 visitor never holds a night pass',                  Imp(s['Vi'], Not(s['Np']))),
    ]
    return s, R

def manual_cnf_examples():
    s, R = policy_kb()
    out = []
    for key in ('R3', 'R6', 'R9'):
        name, e = [r for r in R if r[0].startswith(key + ' ')][0]
        cl = cnf_clauses(e)
        out.append(dict(rule=name, sentence=show(e),
                        cnf=[sorted(c) for c in cl], equivalent_by_truth_table=check_cnf_equivalent(e)))
    return out

def kb_clauses(sentences):
    cl = []
    for e in sentences:
        for c in cnf_clauses(e):
            if c not in cl: cl.append(c)
    return cl

def entail_by_resolution(sentences, alpha, **kw):
    cl = kb_clauses(sentences) + cnf_clauses(Not(alpha))
    return resolution_refute(cl, **kw)

def chain_kb(n):
    sents = [S('p0')] + [Imp(S('p%d' % i), S('p%d' % (i+1))) for i in range(n)]
    return sents, S('p%d' % n)

def php_clauses(k):
    """Pigeonhole: k+1 pigeons, k holes -- unsatisfiable."""
    cl = []
    for i in range(k+1): cl.append(frozenset('x%d_%d' % (i, j) for j in range(k)))
    for j in range(k):
        for a, b in itertools.combinations(range(k+1), 2):
            cl.append(frozenset(['~x%d_%d' % (a, j), '~x%d_%d' % (b, j)]))
    return cl

def tt_unsat(clauses):
    syms = sorted({l.lstrip('~') for c in clauses for l in c})
    idx = {s: i for i, s in enumerate(syms)}
    cl_masks = []
    for c in clauses:
        pos = neg = 0
        for l in c:
            if l[0] == '~': neg |= 1 << idx[l[1:]]
            else: pos |= 1 << idx[l]
        cl_masks.append((pos, neg))
    m = len(syms); t0 = now(); evals = 0; models = 0
    sat = 0
    for b in range(1 << m):
        ok = True
        for pos, neg in cl_masks:
            evals += 1
            if not ((b & pos) or (~b & neg)): ok = False; break
        if ok: sat += 1
    return dict(symbols=m, models_enumerated=1 << m, clause_evals=evals,
                kb_models=sat, time_ms=round((now()-t0)*1000, 2), unsat=(sat == 0))

def task2():
    out = {}
    s, R = policy_kb()
    kb = [e for _, e in R]
    out['policy_rules'] = [n for n, _ in R]
    out['manual_cnf'] = manual_cnf_examples()
    out['policy_clause_count'] = len(kb_clauses(kb))
    # --- policy queries (entailed / not entailed / neither)
    facts_ok = [s['St'], s['Bv'], s['Ho'], Not(s['Em']), Not(s['Rs'])]
    facts_vis = [s['Vi'], s['Bv'], Not(s['Es']), Not(s['Em'])]
    facts_part = [s['Vi'], s['Bv']]
    qs = [('Q-A entailed: staff+badge+hours => door unlocked', kb + facts_ok, s['Un']),
          ('Q-B negation entailed: unescorted visitor => access (alpha)', kb + facts_vis, s['Ac']),
          ('Q-C neither entailed: visitor+badge, escort unknown => access (alpha)', kb + facts_part, s['Ac'])]
    out['policy_queries'] = []
    for name, K, a in qs:
        st, proof = entail_by_resolution(K, a)
        stn, _ = entail_by_resolution(K, Not(a), keep_proof=False)
        mc = tt_entails(K, a)
        out['policy_queries'].append(dict(query=name, resolution_alpha=st, resolution_not_alpha=stn, model_checking=mc))
        if name.startswith('Q-A'):
            out['proof_policy'] = [dict(clause=c, parents=p) for c, p in proof]
    # --- chain family
    out['chain'] = []
    for n in (10, 20, 40, 80):
        K, a = chain_kb(n)
        st, _ = entail_by_resolution(K, a, keep_proof=False)
        row = dict(n=n, symbols=n+1, resolution=st)
        if n <= 20:
            row['model_checking'] = tt_entails(K, a)
        else:
            row['model_checking'] = dict(models_enumerated=2**(n+1), time_ms=None, verdict='infeasible')
        out['chain'].append(row)
    # --- pigeonhole family
    out['php'] = []
    for k in (2, 3, 4, 5):
        cl = php_clauses(k)
        st, _ = resolution_refute(cl, max_generated=60000, keep_proof=False)
        row = dict(k=k, symbols=k*(k+1), clauses=len(cl), resolution=st)
        if k <= 4: row['model_checking'] = tt_unsat(cl)
        else: row['model_checking'] = dict(models_enumerated=2**(k*(k+1)), time_ms=None, verdict='infeasible (2^30 models)')
        out['php'].append(row)
    # --- non-entailed query: termination
    K = kb + facts_part
    st, _ = entail_by_resolution(K, s['Ac'])
    out['non_entailed'] = st
    out['non_entailed_bound'] = dict(symbols=11, max_distinct_nontrivial_clauses=3**11)
    return out


# =====================================================================
# FIRST-ORDER LIBRARY: terms, UNIFY, substitutions, knowledge base, BC
# Variables are strings starting with '?'; compound terms/atoms are tuples
# (functor, arg1, ..., argk); every other value is a constant.
# =====================================================================
def is_var(t): return isinstance(t, str) and t[:1] == '?'
def is_comp(t): return isinstance(t, tuple)

class UStats:
    unify_calls = 0
    @classmethod
    def reset(cls): cls.unify_calls = 0

def walk(t, th):
    while is_var(t) and t in th: t = th[t]
    return t

def occurs_in(v, t, th):
    t = walk(t, th)
    if t == v: return True
    if is_comp(t): return any(occurs_in(v, a, th) for a in t[1:])
    return False

def _unify(x, y, th, occurs):
    if th is None: return None
    x, y = walk(x, th), walk(y, th)
    if x == y: return th
    if is_var(x): return _bind(x, y, th, occurs)
    if is_var(y): return _bind(y, x, th, occurs)
    if is_comp(x) and is_comp(y) and x[0] == y[0] and len(x) == len(y):
        for a, b in zip(x[1:], y[1:]):
            th = _unify(a, b, th, occurs)
            if th is None: return None
        return th
    return None

def _bind(v, t, th, occurs):
    if occurs and occurs_in(v, t, th): return None
    th2 = dict(th); th2[v] = t
    return th2

def unify(x, y, th=None, occurs=True):
    UStats.unify_calls += 1
    return _unify(x, y, {} if th is None else th, occurs)

def subst(t, th, _d=0):
    if _d > 2000: raise RecursionError('cyclic substitution (no occurs check)')
    t = walk(t, th)
    if is_comp(t): return (t[0],) + tuple(subst(a, th, _d+1) for a in t[1:])
    return t

def mgu(th, vars_=None):
    """Idempotent most-general unifier: resolve every binding fully."""
    return {v: subst(t, th) for v, t in th.items() if vars_ is None or v in vars_}

def compose(s1, s2):
    """(s1 then s2): apply s2 to the range of s1, add bindings of s2 for new vars."""
    r = {v: subst(t, s2) for v, t in s1.items()}
    for v, t in s2.items():
        if v not in r: r[v] = t
    return {v: t for v, t in r.items() if v != t}

def term_str(t):
    if is_comp(t): return t[0] + '(' + ', '.join(term_str(a) for a in t[1:]) + ')'
    return str(t)
def sub_str(th): return '{' + ', '.join('%s/%s' % (v, term_str(t)) for v, t in sorted(th.items())) + '}'

_rename_counter = [0]
def rename(t, mp):
    if is_var(t):
        if t not in mp:
            _rename_counter[0] += 1; mp[t] = '%s_%d' % (t, _rename_counter[0])
        return mp[t]
    if is_comp(t): return (t[0],) + tuple(rename(a, mp) for a in t[1:])
    return t
def standardize_apart(rule):
    mp = {}
    return (rename(rule[0], mp), [rename(b, mp) for b in rule[1]])

def variant_key(atom):
    """Canonical form of an atom up to variable renaming (for loop checks/tables)."""
    mp = {}
    def r(t):
        if is_var(t):
            if t not in mp: mp[t] = '?v%d' % len(mp)
            return mp[t]
        if is_comp(t): return (t[0],) + tuple(r(a) for a in t[1:])
        return t
    return r(atom)

def term_vars(t, acc=None):
    acc = set() if acc is None else acc
    if is_var(t): acc.add(t)
    elif is_comp(t):
        for a in t[1:]: term_vars(a, acc)
    return acc

# ---- Lifted Modus Ponens --------------------------------------------
def lifted_mp(rule, facts, stats=None):
    """rule = (head, [premises]); returns list of (conclusion, theta).
    Generalised Modus Ponens: find theta with SUBST(theta, p_i) = SUBST(theta, f_i)."""
    head, prem = standardize_apart(rule)
    out = []
    def rec(i, th):
        if i == len(prem):
            out.append((subst(head, th), mgu(th))); return
        for f in facts:
            if stats is not None: stats['unifications'] += 1
            t2 = unify(prem[i], f, th)
            if t2 is not None: rec(i + 1, t2)
    rec(0, {})
    return out

# ---- Propositionalisation -------------------------------------------
def herbrand_terms(consts, funcs, depth):
    """Ground terms up to nesting depth.  funcs = {name: arity}."""
    terms = list(consts)
    for _ in range(depth):
        new = set(terms)
        for f, k in funcs.items():
            for args in itertools.product(terms, repeat=k):
                new.add((f,) + tuple(args))
        terms = sorted(new, key=lambda t: (is_comp(t), str(t)))
    return terms

def herbrand_count(c, funcs, depth):
    """|T_d| with T_0 = constants and T_{d+1} = T_d U {f(t1..tk)} (exact recurrence;
    new terms are distinct from old ones, so counts are computed as sets)."""
    # count distinct terms by nesting level instead of by value
    levels = [c]; total = c
    cum = c
    prev_total = c
    for d in range(depth):
        # terms with nesting exactly d+1: built from T_d args with at least one arg of exact level d
        new = 0
        for k in funcs.values():
            new += prev_total ** k - (prev_total_before(levels, d) ** k)
        levels.append(new); prev_total += new
    return prev_total
def prev_total_before(levels, d):
    return sum(levels[:d])

def ground_instances(rule, terms):
    head, body = rule
    vs = sorted(term_vars(head).union(*[term_vars(b) for b in body]) if body else term_vars(head))
    for vals in itertools.product(terms, repeat=len(vs)):
        th = dict(zip(vs, vals))
        yield (subst(head, th), [subst(b, th) for b in body])

# ---- First-order knowledge base with backward chaining ----------------
class BudgetExceeded(Exception): pass

class KB:
    def __init__(self, index_facts=True, rule_index_pos=None):
        self.facts = defaultdict(list)       # pred -> [atoms]
        self.fidx = defaultdict(list)        # (pred, pos, val) -> [atoms]
        self.rules = defaultdict(list)       # pred -> [rules]
        self.rkey = defaultdict(list)        # (pred, const) -> rules
        self.rvar = defaultdict(list)        # pred -> rules with variable at pos
        self.index_facts = index_facts
        self.rule_index_pos = rule_index_pos
        self.n_facts = 0; self.n_rules = 0
    def add_fact(self, atom):
        self.facts[atom[0]].append(atom); self.n_facts += 1
        for pos in (0, 1):
            if len(atom) > pos + 1: self.fidx[(atom[0], pos, atom[pos + 1])].append(atom)
    def add_rule(self, head, body):
        r = (head, body)
        self.rules[head[0]].append(r); self.n_rules += 1
        pos = self.rule_index_pos
        if pos is not None and len(head) > pos + 1:
            a = head[pos + 1]
            if is_var(a): self.rvar[head[0]].append(r)
            else: self.rkey[(head[0], a)].append(r)
    def cand_facts(self, goal, th):
        pred = goal[0]
        if not self.index_facts: return self.facts.get(pred, [])
        best = None
        for pos in (0, 1):
            if len(goal) > pos + 1:
                a = walk(goal[pos + 1], th)
                if not is_var(a) and not is_comp(a):
                    c = self.fidx.get((pred, pos, a), [])
                    if best is None or len(c) < len(best): best = c
        return best if best is not None else self.facts.get(pred, [])
    def cand_rules(self, goal, th):
        pred = goal[0]
        pos = self.rule_index_pos
        if pos is not None and len(goal) > pos + 1:
            a = walk(goal[pos + 1], th)
            if not is_var(a) and not is_comp(a):
                return self.rkey.get((pred, a), []) + self.rvar.get(pred, [])
        return self.rules.get(pred, [])

BUILTINS = {'Geq': lambda a, b: a >= b, 'Gt': lambda a, b: a > b, 'Lt': lambda a, b: a < b}

class BC:
    """Backward chaining with substitutions (FOL-BC-ASK), instrumented."""
    def __init__(self, kb, depth_cap=None, loop_check=False, goal_budget=None):
        self.kb = kb; self.depth_cap = depth_cap; self.loop_check = loop_check
        self.goal_budget = goal_budget
        self.goals = 0; self.unifs = 0; self.max_depth = 0; self.repeats = 0
        self.cutoffs = 0; self.pruned_loops = 0; self.seen = set(); self.rule_apps = 0
    def solve(self, goals, th, depth, anc):
        if not goals: yield th; return
        goal = goals[0]; rest = goals[1:]
        g = subst(goal, th)
        self.goals += 1
        if self.goal_budget and self.goals > self.goal_budget: raise BudgetExceeded()
        self.max_depth = max(self.max_depth, depth)
        vk = variant_key(g)
        if vk in self.seen: self.repeats += 1
        else: self.seen.add(vk)
        if g[0] in BUILTINS:
            a, b = g[1], g[2]
            if not is_var(a) and not is_var(b) and BUILTINS[g[0]](a, b):
                yield from self.solve(rest, th, depth, anc)
            return
        if self.loop_check:
            if vk in anc: self.pruned_loops += 1; return
        if self.depth_cap is not None and depth >= self.depth_cap:
            self.cutoffs += 1; return
        anc2 = anc | {vk} if self.loop_check else anc
        for f in self.kb.cand_facts(g, th):
            self.unifs += 1
            t2 = unify(goal, f, th)
            if t2 is not None: yield from self.solve(rest, t2, depth, anc)
        for rule in self.kb.cand_rules(g, th):
            head, body = standardize_apart(rule)
            self.unifs += 1
            t2 = unify(goal, head, th)
            if t2 is not None:
                self.rule_apps += 1
                yield from self.solve(body + rest, t2, depth + 1, anc2)
    def ask(self, goal, limit=None):
        vs = term_vars(goal); out = []
        try:
            for th in self.solve([goal], {}, 0, frozenset()):
                ans = {v: subst(v, th) for v in vs}
                if ans not in out: out.append(ans)
                if limit and len(out) >= limit: break
        except BudgetExceeded:
            return out, True
        except RecursionError:
            return out, True
        return out, False
    def stats(self):
        return dict(goals_expanded=self.goals, unifications=self.unifs, max_depth=self.max_depth,
                    repeated_subgoals=self.repeats, rule_applications=self.rule_apps,
                    depth_cutoffs=self.cutoffs, loop_prunes=self.pruned_loops)

def prove_tree(kb, goal, depth=0, maxd=12):
    """One proof tree (for explanations): returns (tree, theta-instantiated goal) or None."""
    # simple deterministic explanation search (first proof)
    def rec(g, th, d):
        g = subst(g, th)
        if g[0] in BUILTINS:
            a, b = g[1], g[2]
            if not is_var(a) and not is_var(b) and BUILTINS[g[0]](a, b): yield (g, 'builtin', []), th
            return
        for f in kb.cand_facts(g, th):
            t2 = unify(g, f, th)
            if t2 is not None: yield (subst(g, t2), 'fact', []), t2
        if d >= maxd: return
        for rule in kb.cand_rules(g, th):
            head, body = standardize_apart(rule)
            t2 = unify(g, head, th)
            if t2 is None: continue
            def seq(i, tt, kids):
                if i == len(body): yield kids, tt; return
                for sub, t3 in rec(body[i], tt, d + 1):
                    yield from seq(i + 1, t3, kids + [sub])
            for kids, t4 in seq(0, t2, []):
                yield (subst(g, t4), 'rule', [(subst(k[0], t4), k[1], k[2]) for k in kids]), t4
    for tree, th in rec(goal, {}, depth):
        return tree
    return None
def tree_size(t): return 1 + sum(tree_size(k) for k in t[2])
def tree_lines(t, ind=0):
    lines = ['  ' * ind + term_str(t[0]) + '   [' + t[1] + ']']
    for k in t[2]: lines += tree_lines(k, ind + 1)
    return lines


# =====================================================================
# TASK 4 - Unification, lifted inference and propositionalisation
# =====================================================================
def prop_index(ground_rules, facts):
    by_head = defaultdict(list)
    for h, b in ground_rules: by_head[h].append(b)
    return by_head, set(facts)

def prop_backward(index, goal, counter):
    """Propositional backward chaining over indexed ground definite clauses."""
    by_head, fset = index
    memo = {}
    def prove(g, stack):
        counter['steps'] += 1
        if g in fset: return True
        if g in memo: return memo[g]
        if g in stack: return False
        for body in by_head.get(g, []):
            if all(prove(x, stack | {g}) for x in body):
                memo[g] = True; return True
        memo[g] = False; return False
    return prove(goal, frozenset())

def task4():
    out = {}
    A, a_, b_ = '?x', 'John', 'Elizabeth'
    pairs = [
        ('1  P(x, f(y))  vs  P(a, f(b))',                ('P', '?x', ('f', '?y')), ('P', 'a', ('f', 'b')), True),
        ('2  Knows(John, x)  vs  Knows(y, Mother(y))',   ('Knows', 'John', '?x'), ('Knows', '?y', ('Mother', '?y')), True),
        ('3  Q(f(x), g(y))  vs  Q(z, g(f(a)))',          ('Q', ('f', '?x'), ('g', '?y')), ('Q', '?z', ('g', ('f', 'a'))), True),
        ('4  P(x, f(x))  vs  P(f(y), y)   [occurs check]', ('P', '?x', ('f', '?x')), ('P', ('f', '?y'), '?y'), True),
        ('5  Knows(John, x)  vs  Knows(x, Elizabeth)   [standardise apart]', ('Knows', 'John', '?x'), ('Knows', '?x', 'Elizabeth'), True),
    ]
    rows = []
    for name, t1, t2, _ in pairs:
        th = unify(t1, t2)
        row = dict(pair=name, mgu=None if th is None else sub_str(mgu(th)))
        # variant without occurs check
        th_no = unify(t1, t2, occurs=False)
        if th_no is None: row['no_occurs_check'] = 'fails'
        else:
            try: row['no_occurs_check'] = sub_str(mgu(th_no))
            except RecursionError: row['no_occurs_check'] = 'binding returned but SUBST diverges (cyclic term)'
        rows.append(row)
    # standardise apart: rename the second term's variables
    t1, t2 = pairs[4][1], pairs[4][2]
    mp = {}; t2r = rename(t2, mp)
    th = unify(t1, t2r)
    rows[4]['after_standardise_apart'] = sub_str(mgu(th))
    # composition example:  {y/John} then {x/Mother(y)} -> check against subst order
    s1 = {'?x': ('Mother', '?y')}; s2 = {'?y': 'John'}
    out['composition'] = dict(s1=sub_str(s1), s2=sub_str(s2), composed=sub_str(compose(s1, s2)),
                              check=term_str(subst(subst(('Knows', 'John', '?x'), s1), s2)) == term_str(subst(('Knows', 'John', '?x'), compose(s1, s2))))
    out['unifier_tests'] = rows
    # additional clash test
    out['clash'] = dict(pair='P(a, x) vs P(b, y)', result=unify(('P', 'a', '?x'), ('P', 'b', '?y')))
    # lifted modus ponens
    rule = (('Grandparent', '?x', '?z'), [('Parent', '?x', '?y'), ('Parent', '?y', '?z')])
    facts = [('Parent', 'ann', 'bob'), ('Parent', 'bob', 'cy'), ('Parent', 'cy', 'di')]
    st = dict(unifications=0)
    out['lifted_mp_example'] = [dict(conclusion=term_str(c), theta=sub_str(t)) for c, t in lifted_mp(rule, facts, st)]
    out['lifted_mp_unifications'] = st['unifications']
    # ---- ground-clause growth with number of constants k and with arity
    growth = []
    rules_v = {2: (('Anc', '?x', '?y'), [('Par', '?x', '?y')]),
               3: (('Gp', '?x', '?z'), [('Par', '?x', '?y'), ('Par', '?y', '?z')]),
               4: (('Ggp', '?x', '?w'), [('Par', '?x', '?y'), ('Par', '?y', '?z'), ('Par', '?z', '?w')])}
    for k in (3, 5, 10, 15, 20, 25, 30):
        row = dict(k=k)
        consts = ['c%d' % i for i in range(k)]
        for v, rl in rules_v.items():
            if k ** v <= 200000:
                t0 = now(); n = sum(1 for _ in ground_instances(rl, consts)); dt = now() - t0
                row['vars%d' % v] = n; row['vars%d_ms' % v] = round(dt * 1000, 1); row['vars%d_measured' % v] = True
            else:
                row['vars%d' % v] = k ** v; row['vars%d_measured' % v] = False
        growth.append(row)
    out['growth_constants'] = growth
    out['growth_arity'] = [dict(arity=r, k10=10 ** r, k20=20 ** r, k30=30 ** r) for r in range(1, 6)]
    # ---- function symbols: ground terms vs depth bound
    fs = []
    for d in range(0, 6):
        r = dict(depth=d, unary_1const=herbrand_count(1, {'f': 1}, d), unary_2const=herbrand_count(2, {'f': 1}, d),
                 binary_2const=herbrand_count(2, {'f': 1, 'g': 2}, d))
        if d <= 3:
            r['binary_2const_enumerated'] = len(herbrand_terms(['a', 'b'], {'f': 1, 'g': 2}, d))
        r['rule2vars_instances'] = r['binary_2const'] ** 2
        fs.append(r)
    out['growth_function'] = fs
    # ---- lifted versus propositional on the same query
    comp = []
    for k in (5, 10, 20, 30):
        people = ['p%d' % i for i in range(k)]
        kb = KB(index_facts=False)
        for i in range(k - 1): kb.add_fact(('Par', people[i], people[i + 1]))
        kb.add_rule(('Gp', '?x', '?z'), [('Par', '?x', '?y'), ('Par', '?y', '?z')])
        query = ('Gp', 'p0', 'p2')
        bc = BC(kb); t0 = now(); ans, _ = bc.ask(query); dl = now() - t0
        lifted = dict(bc.stats()); lifted.update(answers=len(ans), time_ms=round(dl * 1000, 3))
        # lifted with first-argument indexing
        kb2 = KB(index_facts=True)
        for i in range(k - 1): kb2.add_fact(('Par', people[i], people[i + 1]))
        kb2.add_rule(('Gp', '?x', '?z'), [('Par', '?x', '?y'), ('Par', '?y', '?z')])
        bc2 = BC(kb2); t0 = now(); bc2.ask(query); dl2 = now() - t0
        lifted_idx = dict(bc2.stats()); lifted_idx['time_ms'] = round(dl2 * 1000, 3)
        # propositional: ground all rules over the k constants, then backward chain
        t0 = now()
        grounded = [(subst(h, {}), b) for h, b in ground_instances((('Gp', '?x', '?z'), [('Par', '?x', '?y'), ('Par', '?y', '?z')]), people)]
        facts_g = [('Par', people[i], people[i + 1]) for i in range(k - 1)]
        pidx = prop_index(grounded, facts_g)
        dg = now() - t0
        cnt = dict(steps=0); t0 = now()
        res = prop_backward(pidx, query, cnt); dp = now() - t0
        comp.append(dict(k=k, ground_rules=len(grounded), lifted_noindex=lifted, lifted_indexed=lifted_idx,
                         prop_grounding_ms=round(dg * 1000, 2), prop_steps=cnt['steps'],
                         prop_query_ms=round(dp * 1000, 4), prop_result=res,
                         breakeven_queries=(None if lifted_idx['time_ms'] <= dp * 1000 else
                                            round(dg * 1000 / max(lifted_idx['time_ms'] - dp * 1000, 1e-9), 1))))
    out['lifted_vs_prop'] = comp
    return out


# =====================================================================
# TASK 3 - Knowledge engineering: exam-eligibility advisor (FOL vs propositional)
# =====================================================================
FOL_AXIOMS = [
 ("A1", "forall s,c,p  Attendance(s,c,p) & p>=75 => AttOK(s,c)", "executed"),
 ("A2", "forall s,c,p  ApprovedLeave(s,c) & Attendance(s,c,p) & p>=60 => AttOK(s,c)", "executed"),
 ("A3", "forall s,c,g  Grade(s,c,g) & g>=40 => Passed(s,c)", "executed"),
 ("A4", "forall s  Student(s) => Passed(s,None)", "executed"),
 ("A5", "forall s,c,p  Prereq(c,p) & Passed(s,p) => PrereqOK(s,c)", "executed"),
 ("A6", "forall s  FeePaid(s) => FeesOK(s)", "executed"),
 ("A7", "forall s  Scholarship(s) => FeesOK(s)", "executed"),
 ("A8", "forall s,c  Enrolled(s,c) & AttOK(s,c) & PrereqOK(s,c) & FeesOK(s) & NoDisciplinary(s) => Eligible(s,c)", "executed"),
 ("A9", "forall s,c  Eligible(s,c) => HallTicket(s,c)", "executed"),
 ("A10", "forall c  Course(c) => exists p Prereq(c,p)      [existential; Skolem function p = f(c)]", "integrity check"),
 ("A11", "forall s,c  Eligible(s,c) => Student(s) & Course(c)", "integrity check"),
 ("A12", "forall s  ~(NoDisciplinary(s) & DisciplinaryAction(s))", "integrity check"),
]

def exam_rules(defects=()):
    ge75 = ('Gt', '?p', 75) if 'strict75' in defects else ('Geq', '?p', 75)
    R = [
     (('AttOK', '?s', '?c'), [('Attendance', '?s', '?c', '?p'), ge75]),
     (('AttOK', '?s', '?c'), ([] if 'leave_unchecked' in defects else [('ApprovedLeave', '?s', '?c')]) + [('Attendance', '?s', '?c', '?p'), ('Geq', '?p', 60)]),
     (('Passed', '?s', '?c'), [('Grade', '?s', '?c', '?g'), ('Geq', '?g', 40)]),
     (('PrereqOK', '?s', '?c'), [('Prereq', '?c', '?p'), ('Passed', '?s', '?p')]),
     (('FeesOK', '?s'), [('FeePaid', '?s')]),
     (('FeesOK', '?s'), [('Scholarship', '?s')]),
     (('Eligible', '?s', '?c'), [('Enrolled', '?s', '?c'), ('AttOK', '?s', '?c'), ('PrereqOK', '?s', '?c'), ('FeesOK', '?s'), ('NoDisciplinary', '?s')]),
     (('HallTicket', '?s', '?c'), [('Eligible', '?s', '?c')]),
    ]
    if 'no_none_pass' not in defects:
        R.append((('Passed', '?s', 'None'), [('Student', '?s')]))
    return R

def build_fol(inst, defects=(), index=True):
    kb = KB(index_facts=index)
    for h, b in exam_rules(defects): kb.add_rule(h, b)
    for s in inst['students']: kb.add_fact(('Student', s))
    for c, p in inst['courses']: kb.add_fact(('Course', c)); kb.add_fact(('Prereq', c, p))
    for s, c in inst['enrolled']: kb.add_fact(('Enrolled', s, c))
    for (s, c), p in inst['attendance'].items(): kb.add_fact(('Attendance', s, c, p))
    for (s, c), g in inst['grades'].items(): kb.add_fact(('Grade', s, c, g))
    for s, c in inst['leave']: kb.add_fact(('ApprovedLeave', s, c))
    for s in inst['paid']: kb.add_fact(('FeePaid', s))
    for s in inst['schol']: kb.add_fact(('Scholarship', s))
    for s in inst['nodisc']: kb.add_fact(('NoDisciplinary', s))
    return kb

def hand_instance():
    st = ['alice', 'bob', 'carol', 'dave', 'erin', 'frank', 'gina', 'hari', 'ian']
    courses = [('CS101', 'None'), ('CS201', 'CS101'), ('CS301', 'CS201'), ('MA101', 'None')]
    enrolled = [(s, 'CS101') for s in st] + [('alice', 'CS201'), ('ian', 'CS201'), ('alice', 'CS301'), ('alice', 'MA101'), ('bob', 'MA101')]
    att = {('alice', 'CS101'): 90, ('bob', 'CS101'): 74, ('carol', 'CS101'): 75, ('dave', 'CS101'): 88, ('erin', 'CS101'): 82,
           ('frank', 'CS101'): 91, ('gina', 'CS101'): 65, ('hari', 'CS101'): 65, ('ian', 'CS101'): 80,
           ('alice', 'CS201'): 90, ('ian', 'CS201'): 80, ('alice', 'CS301'): 90, ('alice', 'MA101'): 90, ('bob', 'MA101'): 80}
    grades = {('alice', 'CS101'): 78, ('alice', 'CS201'): 82, ('ian', 'CS101'): 35}
    return dict(students=st, courses=courses, enrolled=enrolled, attendance=att, grades=grades,
                leave={('gina', 'CS101')}, paid=set(st) - {'dave', 'erin'}, schol={'erin'}, nodisc=set(st) - {'frank'})

def query_suite():
    E = lambda s, c: ('Eligible', s, c)
    succeed = [E('alice', 'CS201'), E('carol', 'CS101'), E('erin', 'CS101'), E('gina', 'CS101'), E('bob', 'MA101')]
    fail = [E('bob', 'CS101'), E('dave', 'CS101'), E('frank', 'CS101'), E('hari', 'CS101'), E('ian', 'CS201')]
    st = ['alice', 'bob', 'carol', 'dave', 'erin', 'frank', 'gina', 'hari', 'ian']
    binds = [(E('?s', 'CS101'), '?s', {'alice', 'carol', 'erin', 'gina', 'ian'}),
             (E('alice', '?c'), '?c', {'CS101', 'CS201', 'CS301', 'MA101'}),
             (('HallTicket', '?s', 'CS201'), '?s', {'alice'}),
             (('FeesOK', '?s'), '?s', set(st) - {'dave'}),
             (('AttOK', '?s', 'CS101'), '?s', {'alice', 'carol', 'dave', 'erin', 'frank', 'gina', 'ian'})]
    return succeed, fail, binds

def run_suite(inst, defects):
    kb = build_fol(inst, defects)
    succeed, fail, binds = query_suite()
    res = []
    for q in succeed:
        ans, _ = BC(kb).ask(q); ok = len(ans) > 0
        res.append(dict(type='succeed', query=term_str(q), expected=True, actual=ok, passed=ok is True))
    for q in fail:
        ans, _ = BC(kb).ask(q); ok = len(ans) > 0
        res.append(dict(type='fail', query=term_str(q), expected=False, actual=ok, passed=ok is False))
    for q, v, exp in binds:
        ans, _ = BC(kb).ask(q); got = {a[v] for a in ans}
        res.append(dict(type='bindings', query=term_str(q), expected=sorted(exp), actual=sorted(got), passed=(got == exp)))
    return res

def gen_instance(s, c, seed=7):
    rnd = random.Random(seed)
    students = ['s%d' % i for i in range(s)]
    courses = [('c%d' % j, 'None' if j == 0 else 'c%d' % (j - 1)) for j in range(c)]
    enrolled, att, grades, leave = [], {}, {}, set()
    for st in students:
        for j in range(c):
            cj = 'c%d' % j
            enrolled.append((st, cj)); a = rnd.randint(50, 100); att[(st, cj)] = a
            grades[(st, cj)] = rnd.randint(20, 100)
            if 60 <= a < 75 and rnd.random() < 0.5: leave.add((st, cj))
    paid = {st for st in students if rnd.random() < 0.85}
    schol = {st for st in students if st not in paid and rnd.random() < 0.3}
    nodisc = {st for st in students if rnd.random() < 0.95}
    return dict(students=students, courses=courses, enrolled=enrolled, attendance=att, grades=grades,
                leave=leave, paid=paid, schol=schol, nodisc=nodisc)

def build_prop(inst):
    """Propositional encoding: one instantiated rule set per student and course."""
    pre = dict(inst['courses']); rules, facts = [], []
    for st in inst['students']:
        rules.append((f'FeesOK_{st}', [f'Paid_{st}'])); rules.append((f'FeesOK_{st}', [f'Schol_{st}']))
        if st in inst['paid']: facts.append(f'Paid_{st}')
        if st in inst['schol']: facts.append(f'Schol_{st}')
        if st in inst['nodisc']: facts.append(f'NoDisc_{st}')
    for st, c in inst['enrolled']:
        k = f'{st}_{c}'; p = pre[c]
        facts.append(f'Enr_{k}')
        a = inst['attendance'][(st, c)]
        if a >= 75: facts.append(f'Att75_{k}')
        if a >= 60: facts.append(f'Att60_{k}')
        if (st, c) in inst['leave']: facts.append(f'Leave_{k}')
        if inst['grades'].get((st, c), 0) >= 40: facts.append(f'Grade40_{k}')
        rules.append((f'AttOK_{k}', [f'Att75_{k}']))
        rules.append((f'AttOK_{k}', [f'Leave_{k}', f'Att60_{k}']))
        rules.append((f'Passed_{k}', [f'Grade40_{k}']))
        rules.append((f'PreOK_{k}', [] if p == 'None' else [f'Passed_{st}_{p}']))
        rules.append((f'Eligible_{k}', [f'Enr_{k}', f'AttOK_{k}', f'PreOK_{k}', f'FeesOK_{st}', f'NoDisc_{st}']))
        rules.append((f'Hall_{k}', [f'Eligible_{k}']))
    return rules, facts

def prop_fc(rules, facts):
    """Linear-time propositional forward chaining (agenda + premise counters)."""
    count = [len(b) for h, b in rules]; occ = defaultdict(list)
    for i, (h, b) in enumerate(rules):
        for x in b: occ[x].append(i)
    inferred = set(); agenda = deque(facts); steps = 0
    for i, (h, b) in enumerate(rules):
        if not b: agenda.append(h)
    while agenda:
        p = agenda.popleft()
        if p in inferred: continue
        inferred.add(p)
        for i in occ[p]:
            count[i] -= 1; steps += 1
            if count[i] == 0: agenda.append(rules[i][0])
    return inferred, steps

def task3():
    out = {'axioms': FOL_AXIOMS}
    inst = hand_instance()
    # integrity checks (A10-A12)
    kb = build_fol(inst, ())
    viol = dict(A10=[c for c, _ in inst['courses'] if not any(f[1] == c for f in kb.facts['Prereq'])],
                A11=[a for a in BC(kb).ask(('Eligible', '?s', '?c'))[0] if ('Student', a['?s']) not in kb.facts['Student'] or ('Course', a['?c']) not in kb.facts['Course']])
    out['integrity_violations'] = {k: len(v) for k, v in viol.items()}
    # defect log: run the suite on successive KB versions
    versions = [('v0 (draft: 3 defects)', ('strict75', 'no_none_pass', 'leave_unchecked')),
                ('v1 (fix D1: add Passed(s,None))', ('strict75', 'leave_unchecked')),
                ('v2 (fix D2: >= 75)', ('leave_unchecked',)),
                ('v3 (fix D3: require ApprovedLeave)', ())]
    out['defect_log'] = []
    for name, d in versions:
        r = run_suite(inst, d)
        out['defect_log'].append(dict(version=name, passed=sum(x['passed'] for x in r), total=len(r),
                                      failed=[x['query'] for x in r if not x['passed']]))
    out['defect_isolation'] = []
    for d, name in [('no_none_pass', 'D1 alone'), ('strict75', 'D2 alone'), ('leave_unchecked', 'D3 alone')]:
        r = run_suite(inst, (d,))
        out['defect_isolation'].append(dict(version=name, passed=sum(x['passed'] for x in r), total=len(r),
                                            failed=[x['query'] for x in r if not x['passed']]))
    out['suite_final'] = run_suite(inst, ())
    # propositional version of the same hand instance gives identical eligibility
    rules, facts = build_prop(inst); inferred, _ = prop_fc(rules, facts)
    fol_elig = {(a['?s'], a['?c']) for a in BC(build_fol(inst, ())).ask(('Eligible', '?s', '?c'))[0]}
    prop_elig = {tuple(x.split('_')[1:3]) for x in inferred if x.startswith('Eligible_')}
    out['encodings_agree_on_hand_instance'] = (fol_elig == prop_elig)
    # ---- growth and measurements
    rows = []
    for (s, c) in [(3, 2), (10, 3), (50, 4), (200, 5), (1000, 5), (1000, 10), (3000, 10)]:
        inst = gen_instance(s, c)
        # propositional
        t0 = now(); rules, facts = build_prop(inst); by_head, fset = prop_index(rules, facts); tb_p = now() - t0
        qs, qc = 'Eligible_s%d_c%d' % (s // 2, c // 2), None
        cnt = dict(steps=0); t0 = now(); r1 = prop_backward((by_head, fset), qs, cnt); tq_p = now() - t0
        t0 = now(); inferred, fc_steps = prop_fc(rules, facts); tsweep_p = now() - t0
        elig_p = {x for x in inferred if x.startswith('Eligible_')}
        # first-order
        t0 = now(); kb = build_fol(inst, ()); tb_f = now() - t0
        bc = BC(kb); t0 = now(); r2, _ = bc.ask(('Eligible', 's%d' % (s // 2), 'c%d' % (c // 2))); tq_f = now() - t0
        q_stats = bc.stats()
        bc2 = BC(kb); t0 = now(); allans, _ = bc2.ask(('Eligible', '?s', '?c')); tsweep_f = now() - t0
        elig_f = {'Eligible_%s_%s' % (a['?s'], a['?c']) for a in allans}
        rows.append(dict(s=s, c=c, prop_rules=len(rules), prop_facts=len(facts), prop_sentences=len(rules) + len(facts),
                         prop_rules_formula=6 * s * c + 2 * s,
                         fol_rules=kb.n_rules, fol_facts=kb.n_facts, fol_sentences=kb.n_rules + kb.n_facts,
                         prop_build_ms=round(tb_p * 1000, 2), prop_query_ms=round(tq_p * 1000, 4), prop_query_steps=cnt['steps'],
                         prop_sweep_ms=round(tsweep_p * 1000, 2), prop_sweep_steps=fc_steps,
                         fol_build_ms=round(tb_f * 1000, 2), fol_query_ms=round(tq_f * 1000, 3), fol_query_unifs=q_stats['unifications'],
                         fol_query_goals=q_stats['goals_expanded'],
                         fol_sweep_ms=round(tsweep_f * 1000, 2), fol_sweep_unifs=bc2.stats()['unifications'],
                         single_total_prop_ms=round((tb_p + tq_p) * 1000, 2), single_total_fol_ms=round((tb_f + tq_f) * 1000, 2),
                         sweep_total_prop_ms=round((tb_p + tsweep_p) * 1000, 2), sweep_total_fol_ms=round((tb_f + tsweep_f) * 1000, 2),
                         agree=(elig_p == elig_f), single_agree=(r1 == (len(r2) > 0)), eligible=len(elig_f)))
    out['growth'] = rows
    return out


# =====================================================================
# TASK 5 - First-order resolution with Skolemisation
# =====================================================================
def lit(sign, *atom): return (sign, tuple(atom))

def mask_vars(t):
    if is_var(t): return '?'
    if is_comp(t): return (t[0],) + tuple(mask_vars(a) for a in t[1:])
    return t

def canon_clause(c):
    """Canonical key of a clause up to variable renaming and literal order."""
    ls = sorted(set(c), key=lambda l: (l[0], repr(mask_vars(l[1]))))
    mp = {}
    def r(t):
        if is_var(t):
            if t not in mp: mp[t] = '?v%d' % len(mp)
            return mp[t]
        if is_comp(t): return (t[0],) + tuple(r(a) for a in t[1:])
        return t
    return tuple((sg, r(a)) for sg, a in ls)

def clause_str(c):
    if not c: return '[]'
    return ' | '.join(('' if sg else '~') + term_str(a) for sg, a in c)

class FOLProver:
    def __init__(self, clauses, goal_clauses, strategy='none', max_generated=5000, factoring=True):
        self.strategy = strategy; self.cap = max_generated; self.factoring = factoring
        self.usable = [tuple(c) for c in clauses]; self.goal = [tuple(c) for c in goal_clauses]
        self.st = dict(clauses_generated=0, resolution_steps=0, unification_attempts=0, factors=0,
                       tautologies=0, duplicates=0, given_clauses=0)
    def _key_add(self, c, parents, name):
        k = canon_clause(c)
        if k in self.known: self.st['duplicates'] += 1; return None
        self.known[k] = (c, parents, name); return k
    def run(self):
        t0 = now(); self.known = {}; self.order = []
        passive = []                       # list of (priority, seq, key)
        active = []; by_pred = defaultdict(list)
        seq = [0]
        def push(k):
            c = self.known[k][0]
            pr = len(c) if self.strategy == 'unit' else seq[0]
            seq[0] += 1; passive.append((pr, seq[0], k))
        inputs = []
        for c in self.usable:
            k = self._key_add(c, None, 'axiom')
            if k: inputs.append((k, False))
        for c in self.goal:
            k = self._key_add(c, None, 'negated goal')
            if k: inputs.append((k, True))
        sos_keys = set()
        if self.strategy == 'sos':
            # usable clauses are active from the start; only SOS clauses are 'given'
            for k, is_goal in inputs:
                if is_goal: push(k); sos_keys.add(k)
                else:
                    active.append(k)
                    for sg, a in self.known[k][0]: by_pred[a[0]].append((k, sg))
        else:
            for k, _ in inputs: push(k)
        empty_key = None; capped = False
        while passive and empty_key is None:
            if self.strategy == 'unit': passive.sort()
            _, _, gk = passive.pop(0)
            self.st['given_clauses'] += 1
            g = self.known[gk][0]
            # resolve g with every active clause (and with itself)
            partners = []
            for sg, a in g:
                for (pk, psg) in by_pred.get(a[0], []):
                    if psg != sg and pk not in partners: partners.append(pk)
            if gk not in active:
                active.append(gk)
                for sg, a in g: by_pred[a[0]].append((gk, sg))
            if gk in partners or any(True for sg, a in g for (pk, psg) in by_pred[a[0]] if pk == gk and psg != sg): 
                if gk not in partners: partners.append(gk)
            for pk in partners:
                for newc, desc in self._resolve(gk, pk):
                    self.st['clauses_generated'] += 1
                    nk = self._key_add(newc, (gk, pk), desc)
                    if nk is None: continue
                    if self.strategy == 'sos': sos_keys.add(nk)
                    if not newc: empty_key = nk; break
                    push(nk)
                    if self.factoring:
                        for fc in self._factors(newc):
                            fk = self._key_add(fc, (nk,), 'factor')
                            if fk: push(fk); self.st['factors'] += 1
                    if self.st['clauses_generated'] >= self.cap: capped = True; break
                if empty_key is not None or capped: break
            if capped: break
        self.st['time_ms'] = round((now() - t0) * 1000, 2)
        self.st['proved'] = empty_key is not None
        self.st['capped'] = capped
        self.st['saturated'] = (empty_key is None and not capped)
        self.st['kb_clause_count'] = len(self.known)
        proof = []
        if empty_key is not None:
            seen = set()
            def walk(k):
                if k in seen: return
                seen.add(k); c, par, name = self.known[k]
                if par:
                    for p in par: walk(p)
                proof.append(k)
            walk(empty_key)
            self.st['proof_length'] = sum(1 for k in proof if self.known[k][1] and len(self.known[k][1]) == 2)
            self.proof = [(clause_str(self.known[k][0]), self.known[k][2],
                           [clause_str(self.known[p][0]) for p in (self.known[k][1] or ())]) for k in proof]
        return self.st
    def _resolve(self, k1, k2):
        c1 = self.known[k1][0]; c2 = self.known[k2][0]
        mp1, mp2 = {}, {}
        r1 = [(sg, rename(a, mp1)) for sg, a in c1]; r2 = [(sg, rename(a, mp2)) for sg, a in c2]
        for i, (s1, a1) in enumerate(r1):
            for j, (s2, a2) in enumerate(r2):
                if s1 == s2 or a1[0] != a2[0] or len(a1) != len(a2): continue
                self.st['unification_attempts'] += 1
                th = unify(a1, a2)
                if th is None: continue
                self.st['resolution_steps'] += 1
                res = [(sg, subst(a, th)) for n, (sg, a) in enumerate(r1) if n != i] + \
                      [(sg, subst(a, th)) for n, (sg, a) in enumerate(r2) if n != j]
                res = list(dict.fromkeys(res))
                if any((not sg, a) in res for sg, a in res):
                    self.st['tautologies'] += 1; continue
                yield res, 'resolve on %s with %s' % (term_str(a1[1] if False else a1), sub_str(mgu(th, term_vars(a1) | term_vars(a2))))
    def _factors(self, c):
        out = []
        for i in range(len(c)):
            for j in range(i + 1, len(c)):
                if c[i][0] == c[j][0] and c[i][1][0] == c[j][1][0]:
                    th = unify(c[i][1], c[j][1])
                    if th is not None and (c[i][1] != c[j][1]):
                        f = list(dict.fromkeys((sg, subst(a, th)) for sg, a in c))
                        out.append(f)
        return out

def employee_kb(distractors=0, supervisor=False, retired_query=False):
    """Clauses after CNF conversion and Skolemisation (Sk1 = Skolem constant)."""
    C = [
        [lit(False, 'Employee', '?e'), lit(False, 'Handled', '?e', '?d'), lit(False, 'Restricted', '?d'), lit(True, 'Authorised', '?e')],
        [lit(False, 'ContainsPatientData', '?d'), lit(True, 'Restricted', '?d')],
        [lit(True, 'Employee', 'Sk1')],
        [lit(False, 'Audited', '?d'), lit(True, 'Handled', 'Sk1', '?d')],
        [lit(True, 'ContainsPatientData', 'R1')],
        [lit(True, 'Audited', 'R1')],
    ]
    for i in range(distractors):
        C.append([lit(True, 'Employee', 'E%d' % i)])
        C.append([lit(True, 'ContainsPatientData', 'D%d' % i)])
        C.append([lit(True, 'Audited', 'D%d' % i)])
        C.append([lit(True, 'Handled', 'E%d' % i, 'D%d' % ((i + 1) % max(distractors, 1)))])
    if supervisor:
        C.append([lit(False, 'Employee', '?x'), lit(True, 'Employee', ('sup', '?x'))])
    return C

def ground_for_prop(distractors=0):
    """Ground the FOL clause set over the domain {Sk1, R1, ...} to feed the Task-2 prover."""
    consts = ['Sk1', 'R1'] + ['E%d' % i for i in range(distractors)] + ['D%d' % i for i in range(distractors)]
    clauses = []
    for c in employee_kb(distractors):
        vs = sorted({v for sg, a in c for v in term_vars(a)})
        for vals in itertools.product(consts, repeat=len(vs)):
            th = dict(zip(vs, vals))
            clauses.append(frozenset(('' if sg else '~') + term_str(subst(a, th)).replace(' ', '') for sg, a in c))
    goal = [frozenset(['~Authorised(%s)' % x]) for x in consts]
    return list(dict.fromkeys(clauses)), goal, consts

def task5():
    out = {}
    out['clauses'] = [clause_str(c) for c in employee_kb()] + ['~Authorised(?e)   [negated goal]']
    goal = [[lit(False, 'Authorised', '?e')]]
    rows = []
    for dis in (0, 10, 30):
        for strat in ('none', 'unit', 'sos'):
            p = FOLProver(employee_kb(dis), goal, strat, max_generated=20000)
            UStats.reset(); st = dict(p.run()); st.update(distractors=dis, strategy=strat, unify_calls_total=UStats.unify_calls)
            rows.append(st)
            if dis == 0 and strat == 'sos': out['proof_tree'] = p.proof
    out['strategy_comparison'] = rows
    # not-entailed queries
    ne = []
    for name, kbc, gl in [
        ('Authorised(R1)  [R1 is a document, function-free KB]', employee_kb(0), [[lit(False, 'Authorised', 'R1')]]),
        ('exists e (Employee(e) & Retired(e)), function-free KB', employee_kb(0), [[lit(False, 'Employee', '?e'), lit(False, 'Retired', '?e')]]),
        ('exists e (Employee(e) & Retired(e)), KB + Employee(x)=>Employee(sup(x))', employee_kb(0, supervisor=True), [[lit(False, 'Employee', '?e'), lit(False, 'Retired', '?e')]]),
    ]:
        for strat in ('none', 'sos'):
            p = FOLProver(kbc, gl, strat, max_generated=400)
            st = dict(p.run()); st.update(query=name, strategy=strat); ne.append(st)
    out['non_entailed'] = ne
    # propositional prover (Task 2) on the equivalent grounded domain
    prop = []
    for dis in (0, 3):
        cl, gl, consts = ground_for_prop(dis)
        goal_clause = frozenset('Authorised(%s)' % x for x in consts)   # negation of "some constant is authorised"
        goal_unit = [frozenset(['~Authorised(%s)' % x]) for x in consts]
        st, _ = resolution_refute(cl + goal_unit, keep_proof=True)
        p = FOLProver(employee_kb(dis), [[lit(False, 'Authorised', '?e')]], 'sos', max_generated=20000)
        fst = p.run()
        prop.append(dict(distractors=dis, domain_size=len(consts), ground_input_clauses=len(cl) + len(goal_unit),
                         prop_generated=st['generated'], prop_attempted=st['resolvents_attempted'], prop_proof_len=st.get('proof_length'),
                         prop_refuted=st['refuted'], prop_time_ms=st['time_ms'],
                         fol_input_clauses=len(employee_kb(dis)) + 1, fol_generated=fst['clauses_generated'],
                         fol_unif_attempts=fst['unification_attempts'], fol_proof_len=fst.get('proof_length'), fol_time_ms=fst['time_ms']))
    out['prop_vs_fol'] = prop
    return out


# =====================================================================
# TASK 6 - Forward chaining versus backward chaining on an organisation KB
# =====================================================================
ORG_RULES = [
    (('Reports', '?x', '?y'), [('Manager', '?x', '?y')]),
    (('Reports', '?x', '?z'), [('Manager', '?x', '?y'), ('Reports', '?y', '?z')]),
    (('Colleague', '?x', '?y'), [('Manager', '?x', '?m'), ('Manager', '?y', '?m')]),
    (('SeniorLevel', '?y'), [('Level', '?y', 'L5')]),
    (('SeniorLevel', '?y'), [('Level', '?y', 'L4')]),
    (('CanApprove', '?y', '?x'), [('Reports', '?x', '?y'), ('SeniorLevel', '?y')]),
    (('CanApprove', '?y', '?x'), [('Manager', '?x', '?y'), ('SeniorLevel', '?y')]),
    (('SameDeptReports', '?x', '?y'), [('Reports', '?x', '?y'), ('Dept', '?x', '?d'), ('Dept', '?y', '?d')]),
    (('Escalation', '?x', '?y'), [('Manager', '?x', '?m'), ('Manager', '?m', '?y')]),
    (('Peer', '?x', '?y'), [('Colleague', '?x', '?y'), ('Level', '?x', '?l'), ('Level', '?y', '?l')]),
]
ORG_RULES_LEFT = [r for r in ORG_RULES]
ORG_RULES_LEFT[1] = (('Reports', '?x', '?z'), [('Reports', '?x', '?y'), ('Manager', '?y', '?z')])   # left-recursive

def org_facts(N, branching=5):
    n = (N + 3) // 3
    depth = [0] * n; facts = []
    for i in range(n):
        if i > 0:
            par = (i - 1) // branching; depth[i] = depth[par] + 1
            facts.append(('Manager', 'p%d' % i, 'p%d' % par))
        facts.append(('Level', 'p%d' % i, 'L%d' % max(1, 5 - depth[i])))
    for i in range(n):
        facts.append(('Dept', 'p%d' % i, 'D%d' % (i % 8)))
    return facts, n, depth

class FCEngine:
    """Semi-naive forward chaining to a fixed point (each firing counted once)."""
    def __init__(self, rules, facts):
        self.rules = rules
        self.old = defaultdict(set); self.oidx = defaultdict(list)
        self.delta = defaultdict(set); self.didx = defaultdict(list)
        self.base = set(facts)
        self.facts_in = list(facts)
        self.firings = 0; self.redundant = 0; self.iterations = 0
        self.derived = set(); self.just = {}
    def _add(self, store, idx, f):
        store[f[0]].add(f)
        for pos in (0, 1):
            if len(f) > pos + 1: idx[(f[0], pos, f[pos + 1])].append(f)
    def _cands(self, atom, th, which):
        pred = atom[0]; out = []
        stores = []
        if 'o' in which: stores.append((self.old, self.oidx))
        if 'd' in which: stores.append((self.delta, self.didx))
        for store, idx in stores:
            best = None
            for pos in (0, 1):
                if len(atom) > pos + 1:
                    a = walk(atom[pos + 1], th)
                    if not is_var(a):
                        c = idx.get((pred, pos, a), [])
                        if best is None or len(c) < len(best): best = c
            out += best if best is not None else list(store.get(pred, ()))
        return out
    def _match(self, atom, fact, th):
        self.matches = getattr(self, 'matches', 0) + 1
        if atom[0] != fact[0] or len(atom) != len(fact): return None
        th = dict(th)
        for a, b in zip(atom[1:], fact[1:]):
            a = walk(a, th)
            if is_var(a): th[a] = b
            elif a != b: return None
        return th
    def run(self):
        t0 = now()
        for f in self.facts_in: self._add(self.delta, self.didx, f)
        while True:
            self.iterations += 1
            new = {}
            for head, body in self.rules:
                for i in range(len(body)):
                    for f in list(self.delta.get(body[i][0], ())):
                        th = self._match(body[i], f, {})
                        if th is None: continue
                        self._extend(head, body, i, 0, th, [f] if False else [None] * len(body), f, new)
            for f in self.delta_facts(): pass
            # merge delta into old
            for pred, fs in self.delta.items():
                for f in fs: self._add(self.old, self.oidx, f)
            self.delta = defaultdict(set); self.didx = defaultdict(list)
            if not new: break
            for f, prem in new.items():
                self._add(self.delta, self.didx, f); self.derived.add(f); self.just[f] = prem
        self.time_ms = round((now() - t0) * 1000, 2)
        return self
    def delta_facts(self): return ()
    def _extend(self, head, body, i, j, th, prem, dfact, new):
        if j == len(body):
            self.firings += 1
            h = subst(head, th)
            if h in self.base or h in self.derived or h in new or h in self.old.get(h[0], ()) or h in self.delta.get(h[0], ()):
                self.redundant += 1
            else: new[h] = tuple(prem)
            return
        if j == i:
            prem[j] = dfact; self._extend(head, body, i, j + 1, th, prem, dfact, new); return
        which = 'o' if j < i else 'od'
        atom = body[j]
        for f in self._cands(atom, th, which):
            th2 = self._match(atom, f, th)
            if th2 is not None:
                prem[j] = f; self._extend(head, body, i, j + 1, th2, prem, dfact, new)

def fc_relevance(fc, query_pred, leaf):
    answers = [f for f in fc.derived if f[0] == query_pred and f[2] == leaf]
    rel = set(); stack = list(answers)
    while stack:
        f = stack.pop()
        if f in rel: continue
        rel.add(f)
        for p in fc.just.get(f, ()):
            if p is not None and p in fc.derived: stack.append(p)
    return answers, rel

def true_ancestors(n, leaf_idx, branching=5):
    out = []; i = leaf_idx
    while i > 0:
        i = (i - 1) // branching; out.append('p%d' % i)
    return out

def tabled_ask(kb, rules, goal):
    idb = {h[0] for h, b in rules}
    tables = {}; stats = dict(goals_expanded=0, unifications=0, table_hits=0, iterations=0, max_depth=0)
    def eval_goal(g, visited, depth):
        stats['max_depth'] = max(stats['max_depth'], depth)
        key = variant_key(g)
        tables.setdefault(key, set())
        if key in visited: stats['table_hits'] += 1; return list(tables[key])
        visited.add(key); stats['goals_expanded'] += 1
        for f in kb.cand_facts(g, {}):
            stats['unifications'] += 1
            if unify(g, f) is not None: tables[key].add(f)
        for rule in rules:
            if rule[0][0] != g[0]: continue
            head, body = standardize_apart(rule)
            stats['unifications'] += 1
            th = unify(g, head)
            if th is None: continue
            def solve(k, th):
                if k == len(body):
                    tables[key].add(subst(head, th)); return
                a = subst(body[k], th)
                if a[0] in idb:
                    for ans in eval_goal(a, visited, depth + 1):
                        stats['unifications'] += 1
                        t2 = unify(a, ans, th)
                        if t2 is not None: solve(k + 1, t2)
                else:
                    for f in kb.cand_facts(a, th):
                        stats['unifications'] += 1
                        t2 = unify(a, f, th)
                        if t2 is not None: solve(k + 1, t2)
            solve(0, th)
        return list(tables[key])
    while True:
        stats['iterations'] += 1
        before = sum(len(v) for v in tables.values())
        eval_goal(goal, set(), 0)
        if sum(len(v) for v in tables.values()) == before: break
    return sorted(tables[variant_key(goal)]), stats

def build_org_kb(facts, rules, index=True):
    kb = KB(index_facts=index)
    for f in facts: kb.add_fact(f)
    for h, b in rules: kb.add_rule(h, b)
    return kb

def task6():
    out = {'rules': len(ORG_RULES), 'fc': [], 'bc': [], 'left_recursion': []}
    for N in (100, 1000, 10000):
        facts, n, depth = org_facts(N); leaf = n - 1; leafname = 'p%d' % leaf
        anc = true_ancestors(n, leaf)
        # ---- forward chaining
        fc = FCEngine(ORG_RULES, facts).run()
        answers, rel = fc_relevance(fc, 'CanApprove', leafname)
        per_pred = defaultdict(int)
        for f in fc.derived: per_pred[f[0]] += 1
        out['fc'].append(dict(N=N, base_facts=len(facts), people=n, facts_inferred=len(fc.derived), rule_firings=fc.firings,
                              redundant_derivations=fc.redundant, iterations=fc.iterations,
                              relevant_derived=len(rel), irrelevant_pct=round(100 * (1 - len(rel) / max(len(fc.derived), 1)), 2),
                              answers=len(answers), time_ms=fc.time_ms, derived_by_pred=dict(per_pred)))
        # ---- backward chaining (indexed and unindexed)
        for label, idx in (('indexed', True), ('unindexed', False)):
            kb = build_org_kb(facts, ORG_RULES, idx)
            bc = BC(kb); t0 = now(); ans, _ = bc.ask(('CanApprove', '?y', leafname)); dt = now() - t0
            s = bc.stats(); s.update(N=N, mode=label, answers=len(ans), time_ms=round(dt * 1000, 2))
            out['bc'].append(s)
        # ---- left recursion
        factsL = facts
        kbL = build_org_kb(factsL, ORG_RULES_LEFT, True)
        q = ('Reports', leafname, '?z')
        row = dict(N=N, correct_answers=len(anc))
        bc = BC(kbL, goal_budget=3000); ans, over = bc.ask(q)
        row['naive'] = dict(bc.stats(), answers=len(ans), non_terminating=over)
        bc = BC(kbL, loop_check=True); t0 = now(); ans, over = bc.ask(q)
        row['loop_check'] = dict(bc.stats(), answers=len(ans), non_terminating=over, complete=(len(ans) == len(anc)), time_ms=round((now() - t0) * 1000, 2))
        maxdepth_needed = max(depth) + 2
        bc = BC(kbL, depth_cap=maxdepth_needed); t0 = now(); ans, over = bc.ask(q)
        row['depth_bound'] = dict(bc.stats(), bound=maxdepth_needed, answers=len(ans), complete=(len(ans) == len(anc)), time_ms=round((now() - t0) * 1000, 2))
        t0 = now(); tans, tst = tabled_ask(kbL, ORG_RULES_LEFT, q)
        row['tabling'] = dict(tst, answers=len(tans), complete=(len(tans) == len(anc)), time_ms=round((now() - t0) * 1000, 2))
        out['left_recursion'].append(row)
    return out


# =====================================================================
# TASK 7 - Hospital medication-safety advisor (design, validation)
# =====================================================================
N_DRUGS, N_CLASSES, N_ALLERG, N_COND = 60, 10, 15, 15
def drug(i): return 'D%d' % i
def klass(i): return 'K%d' % (i % N_CLASSES)

def gen_med_specs(total=2000, seed=2026):
    """Rule specifications.  spec[0] is the derived TakesClass rule; spec[k>=1]
    are 'Unsafe' rules.  Prefixes of the list give the 40- and 400-rule KBs."""
    rnd = random.Random(seed)
    types = ['allergy', 'interaction', 'condition', 'pediatric', 'class', 'triple']
    weights = [20, 30, 20, 5, 15, 10]
    specs = [('takesclass',)]; seen = set()
    k = 1
    while len(specs) < total:
        t = types[(k - 1) % 6] if k <= 39 else rnd.choices(types, weights)[0]
        d = rnd.randrange(N_DRUGS)
        if t == 'allergy': sp = (t, d, 'A%d' % rnd.randrange(N_ALLERG))
        elif t == 'interaction': sp = (t, d, drug(rnd.randrange(N_DRUGS)))
        elif t == 'condition': sp = (t, d, 'C%d' % rnd.randrange(N_COND))
        elif t == 'pediatric': sp = (t, d, None)
        elif t == 'class': sp = (t, d, 'K%d' % rnd.randrange(N_CLASSES))
        else: sp = (t, d, (drug(rnd.randrange(N_DRUGS)), 'C%d' % rnd.randrange(N_COND)))
        if sp in seen or (t == 'interaction' and sp[2] == drug(d)): continue
        seen.add(sp); specs.append(sp); k += 1
    return specs

def spec_to_rule(k, sp):
    if sp[0] == 'takesclass':
        return (('TakesClass', '?p', '?k'), [('Takes', '?p', '?d'), ('ClassOf', '?d', '?k')])
    t, d, x = sp; dn = drug(d); head = ('Unsafe', '?p', dn, 'R%d' % k); pr = ('Prescribed', '?p', dn)
    if t == 'allergy': body = [pr, ('Allergy', '?p', x)]
    elif t == 'interaction': body = [pr, ('Takes', '?p', x)]
    elif t == 'condition': body = [pr, ('HasCondition', '?p', x)]
    elif t == 'pediatric': body = [pr, ('Minor', '?p')]
    elif t == 'class': body = [pr, ('TakesClass', '?p', x)]
    else: body = [pr, ('Takes', '?p', x[0]), ('HasCondition', '?p', x[1])]
    return (head, body)

def oracle(specs, size, pt, d_new):
    """Independent imperative check of the rules (does not use the logic engine)."""
    reasons = set(); meds = pt['meds']; classes = {klass(int(m[1:])) for m in meds}
    for k in range(1, size):
        t, d, x = specs[k]
        if drug(d) != d_new: continue
        hit = ((t == 'allergy' and x in pt['allergies']) or (t == 'interaction' and x in meds) or
               (t == 'condition' and x in pt['conds']) or (t == 'pediatric' and pt['age'] < 12) or
               (t == 'class' and x in classes) or (t == 'triple' and x[0] in meds and x[1] in pt['conds']))
        if hit: reasons.add('R%d' % k)
    return reasons

def patient_facts(pt, d_new=None):
    f = [('Age', pt['id'], pt['age'])]
    if pt['age'] < 12: f.append(('Minor', pt['id']))
    f += [('Allergy', pt['id'], a) for a in sorted(pt['allergies'])]
    f += [('Takes', pt['id'], m) for m in sorted(pt['meds'])]
    f += [('HasCondition', pt['id'], c) for c in sorted(pt['conds'])]
    if d_new: f.append(('Prescribed', pt['id'], d_new))
    return f

def med_kb(specs, size, indexed=True):
    kb = KB(index_facts=indexed, rule_index_pos=1 if indexed else None)
    for k in range(size):
        h, b = spec_to_rule(k, specs[k]); kb.add_rule(h, b)
    for i in range(N_DRUGS): kb.add_fact(('ClassOf', drug(i), klass(i)))
    return kb

def kb_pop(kb, facts):
    for f in facts:
        kb.facts[f[0]].remove(f); kb.n_facts -= 1
        for pos in (0, 1):
            if len(f) > pos + 1: kb.fidx[(f[0], pos, f[pos + 1])].remove(f)

def trigger_patient(sp, pid, base_age=45):
    pt = dict(id=pid, age=base_age, allergies=set(), meds=set(), conds=set())
    t, d, x = sp
    if t == 'allergy': pt['allergies'].add(x)
    elif t == 'interaction': pt['meds'].add(x)
    elif t == 'condition': pt['conds'].add(x)
    elif t == 'pediatric': pt['age'] = 8
    elif t == 'class':
        pt['meds'].add(drug([i for i in range(N_DRUGS) if klass(i) == x][0] if True else 0))
    else: pt['meds'].add(x[0]); pt['conds'].add(x[1])
    return pt

def make_cases(specs):
    rnd = random.Random(99); cases = []
    def add(kind, pt, dn): cases.append(dict(kind=kind, pt=pt, drug=dn))
    def pick(lo, hi, n):
        idx = [k for k in range(lo, hi) if specs[k][0] != 'takesclass']
        return rnd.sample(idx, n)
    n = 0
    for kind, (lo, hi, cnt) in [('core (rule<40)', (1, 40, 12)), ('mid (40-399)', (40, 400, 8)), ('late (400-1999)', (400, 2000, 6))]:
        for k in pick(lo, hi, cnt):
            n += 1; add(kind, trigger_patient(specs[k], 'T%d' % n), drug(specs[k][1]))
    # multi-reason: two triggers for the same drug
    by_drug = defaultdict(list)
    for k in range(1, 2000): by_drug[specs[k][1]].append(k)
    for d, ks in list(by_drug.items())[:4]:
        n += 1; a, b = trigger_patient(specs[ks[0]], 'T%d' % n), trigger_patient(specs[ks[1]], 'T%d' % n)
        pt = dict(id=a['id'], age=min(a['age'], b['age']), allergies=a['allergies'] | b['allergies'], meds=a['meds'] | b['meds'], conds=a['conds'] | b['conds'])
        add('multi-reason', pt, drug(d))
    # near-miss safe: trigger facts present but drug differs
    for k in pick(1, 40, 4):
        n += 1; pt = trigger_patient(specs[k], 'T%d' % n); dn = drug((specs[k][1] + 1) % N_DRUGS)
        if oracle(specs, 2000, pt, dn): continue
        add('near-miss safe', pt, dn)
    # random safe patients
    tries = 0
    while sum(1 for c in cases if c['kind'] == 'random safe') < 4 and tries < 5000:
        tries += 1; n += 1
        pt = dict(id='T%d' % n, age=rnd.randint(18, 90), allergies={'A%d' % rnd.randrange(N_ALLERG)},
                  meds={drug(rnd.randrange(N_DRUGS)) for _ in range(3)}, conds={'C%d' % rnd.randrange(N_COND)})
        dn = drug(rnd.randrange(N_DRUGS))
        if not oracle(specs, 2000, pt, dn): add('random safe', pt, dn)
    return cases

def proof_expl(kb, pid, dn):
    t = prove_tree(kb, ('Unsafe', pid, dn, '?r'))
    return t

def task7():
    out = {}
    specs = gen_med_specs(); cases = make_cases(specs)
    out['n_cases'] = len(cases)
    out['rule_type_mix_40'] = {t: sum(1 for s in specs[:40] if s[0] == t) for t in ['takesclass', 'allergy', 'interaction', 'condition', 'pediatric', 'class', 'triple']}
    out['rule_type_mix_2000'] = {t: sum(1 for s in specs if s[0] == t) for t in ['takesclass', 'allergy', 'interaction', 'condition', 'pediatric', 'class', 'triple']}
    out['sizes'] = []; per_case = []
    example = None
    for size in (40, 400, 2000):
        tracemalloc.start(); kb = med_kb(specs, size, True); mem_kb = tracemalloc.get_traced_memory()[0]; tracemalloc.stop()
        kb_un = med_kb(specs, size, False)
        rules_list = [spec_to_rule(k, specs[k]) for k in range(size)]
        base_facts = [('ClassOf', drug(i), klass(i)) for i in range(N_DRUGS)]
        agg = dict(size=size, kb_memory_kib=round(mem_kb / 1024, 1))
        acc = defaultdict(list); correct = dict(bc=0, bc_un=0, fc=0); peak = 0
        for c in cases:
            pt, dn = c['pt'], c['drug']; exp = oracle(specs, size, pt, dn)
            pf = patient_facts(pt, dn)
            # ---- indexed BC (design)
            for f in pf: kb.add_fact(f)
            lat = []
            for _ in range(5):
                bc = BC(kb); t0 = now(); ans, _ = bc.ask(('Unsafe', pt['id'], dn, '?r')); lat.append(now() - t0)
            tracemalloc.start(); BC(kb).ask(('Unsafe', pt['id'], dn, '?r'))
            peak = max(peak, tracemalloc.get_traced_memory()[1]); tracemalloc.stop()
            got = {a['?r'] for a in ans}; st = bc.stats()
            tree = proof_expl(kb, pt['id'], dn)
            if example is None and size == 2000 and len(got) >= 1 and c['kind'] == 'core (rule<40)':
                example = dict(case=c['kind'], patient=pt['id'], drug=dn, lines=tree_lines(tree))
            kb_pop(kb, pf)
            acc['bc_ms'].append(min(lat) * 1000); acc['bc_steps'].append(st['goals_expanded'] + st['unifications'])
            acc['expl_len'].append(tree_size(tree) if tree else 0)
            acc['n_reasons'].append(len(got)); correct['bc'] += (got == exp)
            # ---- unindexed BC baseline
            for f in pf: kb_un.add_fact(f)
            bc2 = BC(kb_un); t0 = now(); ans2, _ = bc2.ask(('Unsafe', pt['id'], dn, '?r')); l2 = now() - t0
            kb_pop(kb_un, pf); st2 = bc2.stats()
            acc['un_ms'].append(l2 * 1000); acc['un_steps'].append(st2['goals_expanded'] + st2['unifications'])
            correct['bc_un'] += ({a['?r'] for a in ans2} == exp)
            # ---- forward chaining baseline
            fc = FCEngine(rules_list, base_facts + pf); t0 = now(); fc.run(); l3 = now() - t0
            got3 = {f[3] for f in fc.derived if f[0] == 'Unsafe' and f[1] == pt['id'] and f[2] == dn}
            acc['fc_ms'].append(l3 * 1000); acc['fc_steps'].append(fc.matches + fc.firings)
            correct['fc'] += (got3 == exp)
            per_case.append(dict(size=size, kind=c['kind'], patient=pt['id'], drug=dn, expected=sorted(exp), got=sorted(got),
                                 ok=(got == exp), goals=st['goals_expanded'], unifs=st['unifications']))
        m = lambda k: round(sum(acc[k]) / len(acc[k]), 3)
        agg.update(cases=len(cases), correct_bc=correct['bc'], correct_unindexed=correct['bc_un'], correct_fc=correct['fc'],
                   bc_latency_ms=m('bc_ms'), bc_steps=m('bc_steps'), unindexed_latency_ms=m('un_ms'), unindexed_steps=m('un_steps'),
                   fc_latency_ms=m('fc_ms'), fc_steps=m('fc_steps'), explanation_nodes=m('expl_len'),
                   max_explanation_nodes=max(acc['expl_len']), unsafe_cases=sum(1 for x in acc['n_reasons'] if x > 0),
                   query_peak_kib=round(peak / 1024, 1))
        out['sizes'].append(agg)
    out['per_case'] = per_case; out['explanation_example'] = example
    # ---- scale test: 50,000 patients in one fact base, 2,000 rules
    rnd = random.Random(5); t0 = now()
    tracemalloc.start()
    kb = med_kb(specs, 2000, True)
    for i in range(50000):
        pid = 'P%d' % i; age = rnd.randint(1, 95)
        kb.add_fact(('Age', pid, age))
        if age < 12: kb.add_fact(('Minor', pid))
        kb.add_fact(('Allergy', pid, 'A%d' % rnd.randrange(N_ALLERG)))
        for _ in range(3): kb.add_fact(('Takes', pid, drug(rnd.randrange(N_DRUGS))))
        for _ in range(2): kb.add_fact(('HasCondition', pid, 'C%d' % rnd.randrange(N_COND)))
    mem_big = tracemalloc.get_traced_memory()[0]; tracemalloc.stop()
    build_s = now() - t0
    ok = 0; steps = []; lats = []
    for c in cases:
        pt, dn = c['pt'], c['drug']; pf = patient_facts(pt, dn)
        for f in pf: kb.add_fact(f)
        bc = BC(kb); t1 = now(); ans, _ = bc.ask(('Unsafe', pt['id'], dn, '?r')); lats.append((now() - t1) * 1000)
        lats[-1] = min(lats[-1], min((lambda b=BC(kb): (lambda t=now(): (b.ask(('Unsafe', pt['id'], dn, '?r')), (now() - t) * 1000)[1])())() for _ in range(2)))
        steps.append(bc.stats()['goals_expanded'] + bc.stats()['unifications'])
        ok += ({a['?r'] for a in ans} == oracle(specs, 2000, pt, dn)); kb_pop(kb, pf)
    # unindexed on the big base: a single query
    kbu = KB(index_facts=False, rule_index_pos=None)
    for k in range(2000):
        h, b = spec_to_rule(k, specs[k]); kbu.add_rule(h, b)
    for pred, fs in kb.facts.items():
        for f in fs: kbu.facts[pred].append(f); kbu.n_facts += 1
    c = cases[0]; pf = patient_facts(c['pt'], c['drug'])
    for f in pf: kbu.add_fact(f)
    bcu = BC(kbu); t1 = now(); bcu.ask(('Unsafe', c['pt']['id'], c['drug'], '?r')); lu = (now() - t1) * 1000
    out['scale'] = dict(patients=50000, rules=2000, facts=kb.n_facts, build_s=round(build_s, 2), memory_mib=round(mem_big / 2**20, 1),
                        cases=len(cases), correct=ok, mean_latency_ms=round(sum(lats) / len(lats), 3), max_latency_ms=round(max(lats), 3),
                        mean_steps=round(sum(steps) / len(steps), 1),
                        unindexed_one_query_ms=round(lu, 1), unindexed_one_query_steps=bcu.stats()['goals_expanded'] + bcu.stats()['unifications'])
    return out


# =====================================================================
# DRIVER: run, save JSON / CSV / text, and draw figures
# =====================================================================
def make_figures(R, outdir):
    try:
        import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    except ImportError:
        print('matplotlib not available - figures skipped'); return
    ev = os.path.join(os.path.dirname(os.path.abspath(outdir)), 'evidence') if False else os.path.join(outdir, '..', 'evidence')
    os.makedirs(ev, exist_ok=True)
    # Fig 1: Wumpus symbols / models
    if 1 in R:
        ns = [c['n'] for c in R[1]['partA']['counts']]
        fig, ax = plt.subplots(figsize=(6, 3.6))
        ax.semilogy(ns, [2 ** c['symbols'] for c in R[1]['partA']['counts']], 'o-', label='full: 2^(4n^2) models')
        ax.semilogy(ns, [2 ** 12] * len(ns), 's-', label='relevant symbols: 2^12 models')
        ax.set_xlabel('world size n'); ax.set_ylabel('models to enumerate'); ax.set_title('Task 1 - model-checking cost'); ax.legend()
        fig.tight_layout(); fig.savefig(os.path.join(ev, 'task1_models.png'), dpi=130); plt.close(fig)
    if 2 in R:
        ch = R[2]['chain']
        fig, ax = plt.subplots(figsize=(6, 3.6))
        ax.semilogy([c['n'] for c in ch], [c['resolution']['generated'] for c in ch], 'o-', label='resolution: clauses generated')
        ax.semilogy([c['n'] for c in ch], [c['model_checking']['models_enumerated'] for c in ch], 's-', label='model checking: models')
        ax.set_xlabel('implication-chain length'); ax.set_title('Task 2 - chain family'); ax.legend()
        fig.tight_layout(); fig.savefig(os.path.join(ev, 'task2_chain.png'), dpi=130); plt.close(fig)
        ph = R[2]['php']
        fig, ax = plt.subplots(figsize=(6, 3.6))
        ax.semilogy([c['k'] for c in ph], [c['resolution']['generated'] for c in ph], 'o-', label='resolution: clauses generated (cap 60,000)')
        ax.semilogy([c['k'] for c in ph], [c['model_checking']['models_enumerated'] for c in ph], 's-', label='model checking: models')
        ax.set_xlabel('holes k (k+1 pigeons)'); ax.set_title('Task 2 - pigeonhole family'); ax.legend(fontsize=8)
        fig.tight_layout(); fig.savefig(os.path.join(ev, 'task2_php.png'), dpi=130); plt.close(fig)
    if 3 in R:
        g = R[3]['growth']; x = [r['s'] * r['c'] for r in g]
        fig, ax = plt.subplots(1, 2, figsize=(9, 3.6))
        ax[0].loglog(x, [r['prop_rules'] for r in g], 'o-', label='propositional rules'); ax[0].loglog(x, [r['fol_rules'] for r in g], 's-', label='FOL rules')
        ax[0].set_xlabel('students x courses'); ax[0].set_title('rule count'); ax[0].legend()
        ax[1].loglog(x, [r['single_total_prop_ms'] for r in g], 'o-', label='prop: build+1 query'); ax[1].loglog(x, [r['single_total_fol_ms'] for r in g], 's-', label='FOL: build+1 query')
        ax[1].loglog(x, [r['sweep_total_prop_ms'] for r in g], 'o--', label='prop: build+sweep'); ax[1].loglog(x, [r['sweep_total_fol_ms'] for r in g], 's--', label='FOL: build+sweep')
        ax[1].set_xlabel('students x courses'); ax[1].set_ylabel('ms'); ax[1].set_title('time'); ax[1].legend(fontsize=7)
        fig.tight_layout(); fig.savefig(os.path.join(ev, 'task3_growth.png'), dpi=130); plt.close(fig)
    if 4 in R:
        g = R[4]['growth_constants']; k = [r['k'] for r in g]
        fig, ax = plt.subplots(figsize=(6, 3.6))
        for v in (2, 3, 4): ax.semilogy(k, [r['vars%d' % v] for r in g], 'o-', label='%d variables (k^%d)' % (v, v))
        ax.set_xlabel('constants k'); ax.set_ylabel('ground rule instances'); ax.set_title('Task 4 - propositionalisation growth'); ax.legend()
        fig.tight_layout(); fig.savefig(os.path.join(ev, 'task4_growth.png'), dpi=130); plt.close(fig)
    if 5 in R:
        rows = R[5]['strategy_comparison']
        fig, ax = plt.subplots(figsize=(6, 3.6)); w = 0.25
        for i, st in enumerate(('none', 'unit', 'sos')):
            ax.bar([j + i * w for j in range(3)], [r['clauses_generated'] for r in rows if r['strategy'] == st], w, label=st)
        ax.set_xticks([j + w for j in range(3)]); ax.set_xticklabels(['0', '10', '30']); ax.set_yscale('log')
        ax.set_xlabel('distractor documents/employees'); ax.set_ylabel('clauses generated'); ax.set_title('Task 5 - strategy comparison'); ax.legend()
        fig.tight_layout(); fig.savefig(os.path.join(ev, 'task5_strategies.png'), dpi=130); plt.close(fig)
    if 6 in R:
        fc = R[6]['fc']; bc = [b for b in R[6]['bc'] if b['mode'] == 'indexed']; bu = [b for b in R[6]['bc'] if b['mode'] == 'unindexed']
        fig, ax = plt.subplots(figsize=(6, 3.6)); N = [r['N'] for r in fc]
        ax.loglog(N, [r['rule_firings'] for r in fc], 'o-', label='forward chaining: rule firings')
        ax.loglog(N, [b['unifications'] for b in bu], 's-', label='backward, no index: unifications')
        ax.loglog(N, [b['unifications'] for b in bc], '^-', label='backward, indexed: unifications')
        ax.set_xlabel('facts'); ax.set_title('Task 6 - work for one query'); ax.legend(fontsize=8)
        fig.tight_layout(); fig.savefig(os.path.join(ev, 'task6_work.png'), dpi=130); plt.close(fig)
    if 7 in R:
        sz = R[7]['sizes']; r = [s['size'] for s in sz]
        fig, ax = plt.subplots(figsize=(6, 3.6))
        ax.loglog(r, [s['bc_steps'] for s in sz], 'o-', label='indexed backward chaining (design)')
        ax.loglog(r, [s['unindexed_steps'] for s in sz], 's-', label='unindexed backward chaining')
        ax.loglog(r, [s['fc_steps'] for s in sz], '^-', label='forward chaining')
        ax.set_xlabel('rules in KB'); ax.set_ylabel('inference steps per query'); ax.set_title('Task 7 - steps vs KB size'); ax.legend(fontsize=8)
        fig.tight_layout(); fig.savefig(os.path.join(ev, 'task7_steps.png'), dpi=130); plt.close(fig)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--out', default='results'); ap.add_argument('--only', nargs='*', type=int)
    a = ap.parse_args(); os.makedirs(a.out, exist_ok=True)
    fns = {1: task1, 2: task2, 3: task3, 4: task4, 5: task5, 6: task6, 7: task7}
    for t in (a.only or sorted(fns)):
        t0 = now(); print('Running Task %d ...' % t, flush=True)
        RESULTS[t] = fns[t](); print('  done in %.1f s' % (now() - t0), flush=True)
    def clean(o):
        if isinstance(o, dict): return {str(k): clean(v) for k, v in o.items()}
        if isinstance(o, (list, tuple)): return [clean(x) for x in o]
        if isinstance(o, (set, frozenset)): return sorted(clean(x) for x in o)
        return o
    with open(os.path.join(a.out, 'results.json'), 'w') as f: json.dump(clean(RESULTS), f, indent=1, default=str)
    import csv
    with open(os.path.join(a.out, 'summary.csv'), 'w', newline='') as f:
        w = csv.writer(f); w.writerow(['task', 'experiment', 'parameter', 'metric', 'value'])
        if 1 in RESULTS:
            for r in RESULTS[1]['partA']['runs']:
                w.writerow([1, r['mode'] + ' ' + r['query'], 'n=%s' % r['n'], 'models_enumerated', r['models_enumerated']])
        if 2 in RESULTS:
            for r in RESULTS[2]['chain']:
                w.writerow([2, 'chain resolution', 'n=%d' % r['n'], 'clauses_generated', r['resolution']['generated']])
            for r in RESULTS[2]['php']:
                w.writerow([2, 'pigeonhole resolution', 'k=%d' % r['k'], 'clauses_generated', r['resolution']['generated']])
        if 3 in RESULTS:
            for r in RESULTS[3]['growth']:
                w.writerow([3, 'prop vs FOL rules', 's=%d,c=%d' % (r['s'], r['c']), 'prop_rules', r['prop_rules']])
        if 4 in RESULTS:
            for r in RESULTS[4]['growth_constants']:
                w.writerow([4, 'ground rules', 'k=%d' % r['k'], 'vars3', r['vars3']])
        if 5 in RESULTS:
            for r in RESULTS[5]['strategy_comparison']:
                w.writerow([5, 'FOL resolution ' + r['strategy'], 'distractors=%d' % r['distractors'], 'clauses_generated', r['clauses_generated']])
        if 6 in RESULTS:
            for r in RESULTS[6]['fc']:
                w.writerow([6, 'forward chaining', 'N=%d' % r['N'], 'rule_firings', r['rule_firings']])
        if 7 in RESULTS:
            for r in RESULTS[7]['sizes']:
                w.writerow([7, 'indexed BC steps', 'rules=%d' % r['size'], 'steps', r['bc_steps']])
    make_figures(RESULTS, a.out)
    print('Results written to', a.out)

if __name__ == '__main__':
    main()
