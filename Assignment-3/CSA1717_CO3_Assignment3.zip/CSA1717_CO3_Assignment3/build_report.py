import json, os
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

BASE = os.path.dirname(os.path.abspath(__file__))
R = json.load(open(os.path.join(BASE, 'results/results.json')))
EV = os.path.join(BASE, 'evidence')
T1, T2, T3, T4, T5, T6, T7 = (R[str(i)] for i in range(1, 8))

doc = Document()
sec = doc.sections[0]
sec.page_width, sec.page_height = Cm(21), Cm(29.7)
for m in ('left_margin', 'right_margin'): setattr(sec, m, Cm(2.2))
sec.top_margin = sec.bottom_margin = Cm(2.2)
st = doc.styles['Normal']; st.font.name = 'Times New Roman'; st.font.size = Pt(11)
st.element.rPr.rFonts.set(qn('w:eastAsia'), 'Times New Roman')
st.paragraph_format.space_after = Pt(5)
for name, size in (('Heading 1', 15), ('Heading 2', 12.5), ('Heading 3', 11.5)):
    h = doc.styles[name]; h.font.name = 'Times New Roman'; h.font.size = Pt(size); h.font.bold = True
    h.font.color.rgb = RGBColor(0, 0, 0); h.element.rPr.rFonts.set(qn('w:eastAsia'), 'Times New Roman')
    h.paragraph_format.space_before = Pt(12); h.paragraph_format.space_after = Pt(5); h.paragraph_format.keep_with_next = True

def shade(cell, color):
    tcPr = cell._tc.get_or_add_tcPr(); sh = OxmlElement('w:shd')
    sh.set(qn('w:val'), 'clear'); sh.set(qn('w:color'), 'auto'); sh.set(qn('w:fill'), color); tcPr.append(sh)

def H(t, l=1): return doc.add_heading(t, level=l)
def P(t='', bold=False, italic=False, align=None, size=None):
    p = doc.add_paragraph(); r = p.add_run(t); r.bold = bold; r.italic = italic
    if size: r.font.size = Pt(size)
    if align == 'c': p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    return p
def PB(label, text):
    p = doc.add_paragraph(); r = p.add_run(label); r.bold = True; p.add_run(text); return p
def BUL(items):
    for t in items:
        p = doc.add_paragraph(style='List Bullet'); p.paragraph_format.space_after = Pt(2)
        if isinstance(t, tuple):
            r = p.add_run(t[0]); r.bold = True; p.add_run(t[1])
        else: p.add_run(t)
def CODE(text):
    t = doc.add_table(rows=1, cols=1); t.alignment = WD_TABLE_ALIGNMENT.CENTER
    c = t.rows[0].cells[0]; shade(c, 'F2F2F2'); c.paragraphs[0].text = ''; c.width = Cm(16.6)
    lines = text.strip('\n').split('\n')
    for i, ln in enumerate(lines):
        p = c.paragraphs[0] if i == 0 else c.add_paragraph()
        p.paragraph_format.space_after = Pt(0)
        r = p.add_run(ln); r.font.name = 'Courier New'; r.font.size = Pt(8.5)
        r._element.rPr.rFonts.set(qn('w:eastAsia'), 'Courier New')
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
def TABLE(header, rows, widths=None, size=9, shade_first=True):
    t = doc.add_table(rows=1, cols=len(header)); t.style = 'Table Grid'; t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(header):
        c = t.rows[0].cells[i]; c.text = ''; r = c.paragraphs[0].add_run(str(h)); r.bold = True; r.font.size = Pt(size)
        if shade_first: shade(c, 'D9D9D9')
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ''; p = cells[i].paragraphs[0]; p.paragraph_format.space_after = Pt(0)
            r = p.add_run('' if v is None else str(v)); r.font.size = Pt(size)
    if not widths:
        widths = [16.6 / len(header)] * len(header)
    tot = sum(widths); widths = [w * 16.6 / tot for w in widths]
    t.autofit = False
    tblPr = t._tbl.tblPr
    lay = OxmlElement('w:tblLayout'); lay.set(qn('w:type'), 'fixed'); tblPr.append(lay)
    for el in tblPr.findall(qn('w:tblW')): tblPr.remove(el)
    tw = OxmlElement('w:tblW'); tw.set(qn('w:w'), str(int(16.6 / 2.54 * 1440))); tw.set(qn('w:type'), 'dxa'); tblPr.append(tw)
    grid = t._tbl.tblGrid
    for i, gc in enumerate(grid.findall(qn('w:gridCol'))): gc.set(qn('w:w'), str(int(widths[i] / 2.54 * 1440)))
    for row in t.rows:
        for i, w in enumerate(widths): row.cells[i].width = Cm(w)
    # repeat header row
    trPr = t.rows[0]._tr.get_or_add_trPr(); th = OxmlElement('w:tblHeader'); th.set(qn('w:val'), 'true'); trPr.append(th)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return t
def FIG(name, caption, width=11.5):
    p = os.path.join(EV, name)
    if os.path.exists(p):
        doc.add_picture(p, width=Cm(width)); doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    c = P(caption, italic=True, align='c', size=10)
def f(x, d=2):
    return f'{x:,.{d}f}' if isinstance(x, float) else (f'{x:,}' if isinstance(x, int) else str(x))
def sci(x): return f'{x:.3e}' if x >= 1e7 else f'{x:,}'

# footer page numbers
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run('CSA1717 Assignment 3 (CO3) - page '); run.font.size = Pt(9)
r2 = fp.add_run(); r2.font.size = Pt(9)
for tag, txt in (('begin', None), (None, 'PAGE'), ('end', None)):
    if tag:
        e = OxmlElement('w:fldChar'); e.set(qn('w:fldCharType'), tag); r2._r.append(e)
    else:
        e = OxmlElement('w:instrText'); e.set(qn('xml:space'), 'preserve'); e.text = txt; r2._r.append(e)

# ====================================================================== COVER
P('SAVEETHA INSTITUTE OF MEDICAL AND TECHNICAL SCIENCES', bold=True, align='c', size=13)
P('(Declared as Deemed to be University under Section 3 of UGC Act 1956)', align='c', size=9)
P('')
P('CSA1717 - ARTIFICIAL INTELLIGENCE', bold=True, align='c', size=15)
P('ASSIGNMENT 3 - CO3', bold=True, align='c', size=13)
p = P(); p.add_run('CO3: ').bold = True
p.add_run('Logical agents, propositional logic, reasoning patterns, resolution, first-order logic, knowledge engineering in FOL, '
          'inference in first-order logic, unification and lifting, forward chaining, backward chaining, resolution.')
PB('GitHub Repository URL: ', '____________________________________________')
TABLE(['Field', 'Details', 'Field', 'Details'], [
    ['Student A', '______________________', 'Register Number (A)', '______________'],
    ['Student B', '______________________', 'Register Number (B)', '______________'],
    ['Department / Section', 'B.Tech IT', 'Academic Year / Semester', 'AUG-DEC 2026'],
    ['Faculty Name', 'Dr. R. Pitchandi', 'Nature of Assignment', 'Pair work (2 students)'],
    ['Duration', '1 Week', 'Total Marks', '50'],
    ['Course Code', 'CSA1717', 'Course', 'Artificial Intelligence']], widths=[3.6, 4.4, 4.2, 4.4], size=10)

H('MANDATORY SUBMISSION EVIDENCE CHECK', 2)
P('Included = reproduced in this report or the implementation package.', size=10)
TABLE(['Task / Item', 'Evidence expected', 'Status', 'Evidence location'], [
    ['1', 'KB listing, symbol-count derivation, checker code and outputs for three query types, inference derivations with step counts, soundness tables, comparison', 'Included', 'Sections 1.1-1.8; Figure 1.1'],
    ['2', 'Manual CNF, proof, both implementations, clause and model counts across KB sizes, KB families, joint design discussion', 'Included', 'Sections 2.1-2.7; Figures 2.1-2.2'],
    ['3', 'Vocabulary and axioms, growth derivation, query suite, defect log, size/time tables, conclusion', 'Included', 'Sections 3.1-3.7; Figure 3.1'],
    ['4', 'Unifier code and tests, hand derivations, ground-clause growth tables and plots, lifted vs propositional comparison, decision', 'Included', 'Sections 4.1-4.7; Figure 4.1'],
    ['5', 'Conversion steps, proof tree, prover code, strategy comparison, non-entailed behaviour, cross-understanding answers', 'Included', 'Sections 5.1-5.7; Figure 5.1'],
    ['6', 'Two engines, metric tables for 100/1,000/10,000 facts, non-termination demonstration, remedy, verification answers', 'Included', 'Sections 6.1-6.6; Figure 6.1'],
    ['7', 'Six-stage design challenge with code and outputs', 'Included', 'Sections 7.1-7.8; Figure 7.1'],
    ['Source code', 'Python implementation', 'Included', 'src/assignment3_co3.py (ZIP)'],
    ['Experimental data', 'Machine-readable results', 'Included', 'results/results.json, summary.csv, execution_output.txt'],
    ['Visual evidence', 'Plots generated from the experiments', 'Included', 'evidence/*.png']], widths=[2.0, 7.2, 1.8, 5.6], size=9)

H('IMPLEMENTATION EVIDENCE CHAIN', 2)
TABLE(['Evidence item', 'Status', 'Observation'], [
    ['Algorithm design and pseudocode', 'Included', 'Design decisions and procedures are described for Tasks 1-7.'],
    ['Python source code', 'Included', 'Single reproducible file implements every experiment.'],
    ['Correctness checks', 'Included', 'Every inference-rule step is verified by truth table; CNF conversions are checked for equivalence; engines are checked against an independent oracle (Task 7) and against each other (Tasks 3, 5).'],
    ['Generated test cases', 'Included', 'Wumpus scenarios, policy KBs, pigeonhole and chain families, exam instances, organisation trees and patient records are defined in code with fixed seeds.'],
    ['Operation-count evidence', 'Included', 'Models, sentence evaluations, clauses, resolvents, unifications, goals, rule firings and inference steps are recorded.'],
    ['Execution output', 'Included', 'results/execution_output.txt and results.json.']], widths=[4.2, 1.8, 10.6], size=9)

doc.add_page_break()
H('ANSWERS', 1)
H('Introduction', 2)
P('This assignment investigates how logical reasoning methods behave as the knowledge base (KB), the query and the domain grow. '
  'Seven problems are studied: a Wumpus-world logical agent, a smart-building access policy, a university exam-eligibility advisor, '
  'unification and lifted inference, a first-order resolution prover, forward and backward chaining on an organisation hierarchy, and a '
  'hospital medication-safety advisor. Each task follows the same cycle: represent the knowledge, choose an inference procedure, implement it, '
  'measure operation counts, debug and evaluate. Operation counts are treated as primary evidence; execution time is supplementary.')
P('The results describe the supplied test instances only. Where a result depends on a design choice (for example clause selection order, '
  'index structure or the closed-world assumption) this is stated.')
H('Experimental environment and reproducibility', 2)
TABLE(['Item', 'Configuration'], [
    ['Language', 'Python 3.10 or later (tested on 3.12)'],
    ['Dependencies', 'Standard library only; Matplotlib is needed only to regenerate figures'],
    ['Randomness', 'Fixed seeds for exam instances, patient records and the rule generator; PYTHONHASHSEED=0 fixes set-iteration order so that the cap-limited pigeonhole runs are reproducible'],
    ['Output files', 'results/results.json, results/summary.csv, results/execution_output.txt, evidence/*.png'],
    ['Execution command', 'PYTHONHASHSEED=0 python src/assignment3_co3.py --out results']], widths=[3.8, 12.8], size=10)

# ====================================================================== TASK 1
H('Task 1 - Logical Agents: Knowledge Bases, Entailment and Reasoning Patterns', 1)
H('1.1 Knowledge base (shared work)', 2)
P('For an n x n world every square (x,y) has four proposition symbols: P(x,y) pit, W(x,y) wumpus, B(x,y) breeze and S(x,y) stench. '
  'The general rules, independent of any percept, are:')
BUL(['R1: ~P11 and ~W11 (the start square is safe).',
     'R2: for every square, B(x,y) <=> OR of P over the neighbouring squares (breeze rule).',
     'R3: for every square, S(x,y) <=> OR of W over the neighbouring squares (stench rule).',
     'R4: at least one wumpus exists: OR of W(x,y) over all squares.',
     'R5: at most one wumpus exists: for every pair of squares, ~W(a) | ~W(b).'])
P('Percepts are added as facts: for the standard scenario the agent visits [1,1] (no breeze, no stench), [2,1] (breeze, no stench) and [1,2] (stench, no breeze). '
  'The three percept queries were: entailed (is [2,2] safe), negation entailed (is there a pit at [2,2]) and neither entailed (is there a pit at [3,2]). '
  'A fourth query (pit at [3,1]) is a second entailed case.')
H('1.2 Symbol and sentence counts - Student A', 2)
P('Symbols: 4n^2. Sentences: 2 (R1) + 2n^2 (R2, R3) + 1 (R4) + n^2(n^2-1)/2 (R5) = 3 + 2n^2 + n^2(n^2-1)/2. '
  'The number of models is 2^m with m = 4n^2, so it grows as 2^(4n^2).')
TABLE(['n', 'Symbols m = 4n^2', 'Sentences', 'Models 2^m'],
      [[c['n'], c['symbols'], c['sentences'], sci(2 ** c['symbols'])] for c in T1['partA']['counts']], widths=[1.5, 3.5, 3.5, 5], size=10)
P('The derived counts equal the sizes of the KBs built by the program (17, 57 and 155 sentences for n = 2, 3, 4).')
PB('Minimal relevant symbol set. ', 'For the query "is [2,2] safe" the sentences that can constrain P22 and W22 are the percept rules of the visited squares '
   '[1,1], [2,1], [1,2]. These mention only P and W symbols of the squares {11, 21, 12, 31, 22, 13}, i.e. 12 symbols (2^12 = 4,096 models) '
   'regardless of n. For a pit-only query 6 symbols suffice. The relevant set depends on the number of visited squares and their neighbours, not on n^2.')
PB('Soundness and completeness of model checking. ', 'The checker enumerates every assignment to the symbols and reports "entailed" only if the query is true in every model of the KB. '
   'It is sound because no counter-model exists when it answers yes (it has examined all models), and complete because every entailed sentence is true in all models and will therefore be confirmed - '
   'the model space is finite. The price is time O(2^m) (space O(m) when models are generated one at a time). '
   'Restricting to relevant symbols preserves soundness (a subset of the KB entailing the query implies the full KB entails it) but a "neither" verdict from a restricted KB must be confirmed against the full KB; '
   'this was done for n = 2 (below) and for n = 3, 4 by exhibiting two extensions of the restricted models with different values of the queried symbol.')
H('1.3 Experimental validation - Student B', 2)
rows = []
for r in T1['partA']['runs']:
    if r['verdict'] == 'infeasible':
        rows.append([r['n'], 'full', r['symbols'], sci(r['models_enumerated']), '-', 'infeasible', f"projected {f(r['projected_seconds'],0)} s" if r['projected_seconds'] < 1e6 else f"projected {r['projected_years']:.2e} years"])
    else:
        rows.append([r['n'], 'full' if r['mode'].startswith('full') else 'relevant', r['symbols'], f(r['models_enumerated']), f(r['sentence_evals']), r['verdict'], f(r['time_ms'])+' ms'])
TABLE(['n', 'Symbols used', 'm', 'Models enumerated', 'Sentence evaluations', 'Verdict', 'Time / projection'], rows, widths=[1, 2.2, 1, 3, 3, 3.2, 3.4], size=8.5)
P('Queries for n = 2 (KB: only [1,1] visited, no percepts): [1,2] safe (entailed), pit at [1,2] (negation entailed), pit at [2,2] (neither). '
  'Queries for n = 3, 4 are Q1 [2,2] safe (entailed), Q2 pit at [2,2] (negation entailed), Q3 pit at [3,2] (neither entailed), Q4 pit at [3,1] (entailed). '
  'For n = 2 each query appears twice (full symbols, then relevant symbols) and both give the same verdict, which validates the restriction; for n = 3 and 4 the four relevant-symbol queries are followed by the infeasibility row for the full symbol set.')
P(f"Feasibility boundary: the full symbol set is feasible for n = 2 (65,536 models, about 12 ms). For n = 3 it needs 2^36 = 6.9 x 10^10 models; even at the best measured throughput "
  f"({T1['partA']['throughput_models_per_s']:,} models/s, which is optimistic because most models fail on the first KB sentence) that is about "
  f"{T1['partA']['runs'][10]['projected_seconds']:,.0f} s (about 3.5 hours). For n = 4 it is 2^64 models, about {T1['partA']['runs'][-1]['projected_years']:,.0f} years. "
  "With the relevant-symbol restriction every n = 3 and n = 4 query is answered in 4,096 or 16,384 models (under 3 ms), and the cost does not depend on n.")
FIG('task1_models.png', 'Figure 1.1 - Models enumerated with the full symbol set versus relevant symbols.', 10)
H('1.4 Reasoning patterns - inference-rule derivation (shared work)', 2)
B = T1['partB']
P('Instead of model checking, the safety of squares was derived using Modus Ponens (MP), And-Elimination (AE) and Unit Resolution (UR). '
  'The local rules were first rewritten with sound equivalence steps (biconditional elimination, contraposition, De Morgan); these are listed as "rewrite" steps and counted separately from the three inference rules. '
  'Each step was machine-checked: premises entail conclusion over all assignments to the symbols involved.')
rows = [[s['n'], s['rule'] + ('' if s['kind'] == 'inference' else ' (rewrite)'), '; '.join(s['premises']), s['conclusion']] for s in B['steps']]
TABLE(['#', 'Rule', 'Premises', 'Conclusion'], rows, widths=[0.8, 3.6, 7.2, 5], size=8)
P(f"Result: square [2,2] is safe: derived ~P22 (steps 1-8) and ~W22 (steps 9-16), then combined by And-Introduction (step 17). "
  f"Square [1,3] is not safe: ~P13 was obtained in step 8 but W13 is derived in steps 18-21 (MP, then two UR steps) from the stench at [1,2]. "
  f"As a by-product a pit at [3,1] is derived in steps 22-25.")
P('Step counts (inference rules only): [2,2] safe = 10 (8 AE + 2 MP); [1,3] has a wumpus = 3 (1 MP + 2 UR, reusing ~P13); pit at [3,1] = 3. '
  f"Including rewrites the whole derivation has {B['total_steps_incl_rewrites']} steps.")
TABLE(['Query', 'Inference-rule steps', 'Model checking (relevant symbols)', 'Model checking (full symbols)'], [
    ['[2,2] safe', B['safe22_inference_steps'], f"{f(B['mc_safe22']['models_enumerated'])} models, {f(B['mc_safe22']['sentence_evals'])} sentence evaluations", 'infeasible for n = 3 (2^36 models)'],
    ['[1,3] safe (answer: no)', B['unsafe13_inference_steps'], f"{f(B['mc_safe13']['models_enumerated'])} models, {f(B['mc_safe13']['sentence_evals'])} sentence evaluations", 'infeasible for n = 3 (2^36 models)']],
      widths=[3.2, 3.2, 6, 4.2], size=9)
P('The derivation needs two to three orders of magnitude fewer operations than enumeration, and, unlike enumeration, its cost does not depend on the number of symbols. '
  'Its limitation is incompleteness: the three rules do not derive everything that is entailed (for example the contrapositive steps had to be supplied), so a failed derivation proves nothing.')
H('1.5 Soundness of the rules - Student B', 2)
for t in B['soundness_tables']:
    P(t['rule'], bold=True)
    TABLE(['a', 'b', 'premises true?', 'conclusion true?'], [[r['a'], r['b'], r['prem'], r['concl']] for r in t['rows']], widths=[2, 2, 4, 4], size=9)
    P('Sound: ' + ('yes - in every row where all premises are true the conclusion is true.' if t['sound'] else 'NO'))
P('Why a derived sentence holds in every model of the KB: by induction on the length of the derivation. The KB sentences hold in every model of the KB. '
  'If all premises of a step hold in a model M, the truth table shows the conclusion holds in M. Hence every derived sentence is true in every model of the KB, i.e. it is entailed.')
P('Why "not derived" is not the same as "false": a derivation procedure that is sound but incomplete may fail to find a proof of an entailed sentence; and even a complete procedure that fails only shows the sentence is not entailed. '
  'Entailment of a sentence is different from entailment of its negation. In the experiment, "pit at [3,2]" cannot be derived and its negation cannot be derived either; model checking confirms that the KB has two models, '
  'one with and one without a pit at [3,2] (verdict "neither entailed"), so the sentence is neither provable nor refutable - it is simply unknown.')
H('1.6 Comparison of the two reasoning approaches', 2)
TABLE(['Property', 'Model checking', 'Inference rules'], [
    ['Completeness', 'Complete (finite models)', 'Only as complete as the rules and search strategy'],
    ['Cost', '2^m models (m = relevant symbols)', '10 inference steps for [2,2] safe'],
    ['Handles "neither"', 'Yes - shows two distinct models', 'Cannot tell "unknown" from "failed to find"'],
    ['Explanation', 'None (a verdict)', 'The derivation is the explanation'],
    ['Scaling in n', 'Exponential without symbol selection', 'Independent of n for local reasoning']], widths=[3.5, 6.5, 6.5], size=9)
H('1.7 Cross-understanding', 2)
P('Student A can explain Student B\'s experiment: the 4,096 vs 65,536 models come from the 12 versus 16 symbols; the verdicts are classified by comparing the number of KB models in which the query is true with the total number of KB models. '
  'Student B can explain Student A\'s derivation: 4n^2 symbols and 3 + 2n^2 + n^2(n^2-1)/2 sentences. The at-most-one-wumpus rule alone contributes n^2(n^2-1)/2 sentences, which dominates for large n.')

# ====================================================================== TASK 2
H('Task 2 - The Quality of Reasoning Method: Model Checking versus Resolution', 1)
H('2.1 Access-control policy (13 rules)', 2)
P('Symbols: Bv badge valid, St staff, Vi visitor, Es escorted, Ho business hours, Em emergency, Np night pass, Rs restricted area, Ac access granted, Un door unlocked, Lg access logged.')
TABLE(['Rule'], [[x] for x in T2['policy_rules']], widths=[16.5], size=9)
P(f"The rules use implication (R1-R4, R8-R13), biconditional (R5-R7) and disjunction (R8, R9). The KB converts to {T2['policy_clause_count']} distinct CNF clauses over 11 symbols.")
H('2.2 Manual CNF conversion - Student A', 2)
P('Rule R3: (Vi & Es & Bv) => Ac', bold=True)
CODE('''1. Eliminate =>:   ~(Vi & Es & Bv) | Ac
2. Move ~ inward (De Morgan):  (~Vi | ~Es | ~Bv) | Ac
3. Already a single clause:   { ~Vi, ~Es, ~Bv, Ac }''')
P('Rule R6: Un <=> Ac', bold=True)
CODE('''1. Eliminate <=>:  (Un => Ac) & (Ac => Un)
2. Eliminate =>:    (~Un | Ac) & (~Ac | Un)
3. Two clauses:     { ~Un, Ac }   { ~Ac, Un }''')
P('Rule R9: (Ac & Rs) => ((St & Bv) | Em)', bold=True)
CODE('''1. Eliminate =>:   ~(Ac & Rs) | ((St & Bv) | Em)
2. De Morgan:       (~Ac | ~Rs) | ((St & Bv) | Em)
3. Distribute | over &:   (~Ac | ~Rs | St | Em) & (~Ac | ~Rs | Bv | Em)
4. Two clauses:     { ~Ac, ~Rs, St, Em }   { ~Ac, ~Rs, Bv, Em }''')
P('The program converts the same three sentences and confirms by truth table that each CNF is equivalent to the original: ' +
  ', '.join(f"{c['rule'][:3]} {c['equivalent_by_truth_table']}" for c in T2['manual_cnf']) + '.')
H('2.3 Resolution proof of an entailed query - Student A', 2)
P('Facts: staff, valid badge, business hours, no emergency, not restricted. Query: door unlocked (Un). To prove KB |= Un, add ~Un and derive the empty clause. Proof (input clauses and resolvents only):')
rows = []
for i, e in enumerate(T2['proof_policy']):
    if e['parents'] is None: rows.append([i + 1, '{' + ', '.join(e['clause']) + '}', 'input clause'])
    else: rows.append([i + 1, '{' + ', '.join(e['clause']) + '}' if e['clause'] else '{} (empty clause)', 'resolvent of ' + '{' + ', '.join(e['parents'][0]) + '}' + ' and ' + '{' + ', '.join(e['parents'][1]) + '}'])
TABLE(['#', 'Clause', 'Origin'], rows, widths=[0.8, 5.2, 10.5], size=8.5)
P('Proof tree (leaves = input clauses): {St} and {Ac,~Bv,~Ho,~St} give {Ac,~Bv,~Ho}; with {Ho} this gives {Ac,~Bv}. {~Un} with {Un,~Ac} gives {~Ac}. '
  '{Ac,~Bv} with {~Ac} gives {~Bv}, and {~Bv} with {Bv} gives the empty clause. Proof length: 5 resolution steps.')
TABLE(['Query', 'KB |= alpha ?', 'KB |= ~alpha ?', 'Model checking verdict', 'Resolution clauses generated'], [
    ['Q-A: staff+badge+hours => Un', 'yes (refuted ~alpha)', 'no', T2['policy_queries'][0]['model_checking']['verdict'], T2['policy_queries'][0]['resolution_alpha']['generated']],
    ['Q-B: unescorted visitor => Ac', 'no', 'yes', T2['policy_queries'][1]['model_checking']['verdict'], T2['policy_queries'][1]['resolution_not_alpha']['generated']],
    ['Q-C: visitor+badge, escort unknown => Ac', 'no', 'no', T2['policy_queries'][2]['model_checking']['verdict'], T2['policy_queries'][2]['resolution_alpha']['generated']]], widths=[4.8, 3, 3, 3, 2.7], size=8.5)
H('2.4 Implication chains - resolution cost versus KB size', 2)
P('Family A: facts p0, rules p_i => p_(i+1) for i < n, query p_n. Resolution uses a given-clause loop with tautology deletion, forward and backward subsumption.')
rows = []
for c in T2['chain']:
    r = c['resolution']; mc = c['model_checking']
    rows.append([c['n'], r['input_clauses'], r['generated'], r['resolvents_attempted'], r['tautologies_discarded'], r['subsumed_removed'], f(r['time_ms'], 1), sci(mc['models_enumerated']), f(mc['time_ms'], 0) if mc.get('time_ms') else 'infeasible'])
TABLE(['n', 'Input clauses', 'Clauses generated', 'Resolvents attempted', 'Tautologies discarded', 'Subsumed removed', 'Res. time ms', 'Models 2^(n+1)', 'MC time ms'], rows, size=8.5)
FIG('task2_chain.png', 'Figure 2.1 - Chain family: clauses generated by resolution versus models enumerated.', 10)
P('Generated clauses grow 66, 231, 861, 3,321 - the ratio approaches 4 per doubling of n, i.e. quadratic growth (resolution derives every clause p_i => p_j). Model checking needs 2^(n+1) models: 2,048, 2.1 million (about 0.37 s), and is infeasible for n = 40 (2^41) and n = 80 (2^81).')
H('2.5 Pigeonhole family - where model checking wins', 2)
P('Family B: k+1 pigeons, k holes; x_ij means pigeon i is in hole j. Clauses: every pigeon in some hole; no two pigeons share a hole. The KB is unsatisfiable, so both methods must establish unsatisfiability. Resolution was capped at 60,000 generated clauses.')
rows = []
for c in T2['php']:
    r = c['resolution']; mc = c['model_checking']
    rows.append([c['k'], c['symbols'], c['clauses'], f(r['generated']) + (' (cap reached)' if r['hit_cap'] else ''), f(r['resolvents_attempted']), f(r['time_ms'], 1), f(mc['models_enumerated']) if mc.get('time_ms') else '2^30 (infeasible)', f(mc['time_ms'], 1) if mc.get('time_ms') else '-'])
TABLE(['k', 'Symbols', 'Input clauses', 'Resolution clauses generated', 'Resolvents attempted', 'Res. time ms', 'MC models', 'MC time ms'], rows, size=8.5)
FIG('task2_php.png', 'Figure 2.2 - Pigeonhole family: resolution clause growth versus model enumeration.', 10)
P('For k = 3 (12 symbols) model checking needs 4,096 models and 1.0 ms; resolution needs 59,504 clauses and 1,754 ms (about 1,700 times slower). For k = 4 resolution is still unfinished after 60,000 clauses while enumeration of 1,048,576 models completes in about 0.39 s. At k = 5 enumeration (2^30 models) is infeasible in this environment but resolution has also not finished.')
H('2.6 Structural explanation and termination - Students A and B', 2)
BUL([('Chains (resolution strong): ', 'the clauses are Horn and sparse; each resolvent shortens a chain, so a refutation of polynomial size exists. Model checking ignores structure: it pays 2^m however simple the KB is.'),
     ('Pigeonhole (model checking strong): ', 'few symbols but densely interacting non-Horn clauses; every resolution refutation is exponentially long (Haken, 1985), while 2^m is small because m <= 20.'),
     ('Termination on a non-entailed query (Q-C): ', f"resolution saturated after {T2['non_entailed']['generated']} generated clauses with no empty clause. The set of clauses over 11 symbols is finite (at most 3^11 = 177,147 non-tautological clauses) and the algorithm never regenerates a clause it has seen, so the queue must empty; an empty queue without the empty clause proves the query is not entailed.")])
H('2.7 Joint design question', 2)
P('Before choosing, I would want: (1) the number of symbols m after relevance filtering - if m is at most about 20 the 2^m bound is acceptable; (2) whether the KB is Horn or sparse (chain-like) - then resolution or chaining is polynomial; '
  '(3) the clause-to-symbol density and whether the KB is near-contradictory or contains symmetric constraints (pigeonhole-like), where resolution proofs blow up; (4) the query mix (many queries over a fixed KB favours compiling the KB once); '
  '(5) whether a proof/explanation is required; and (6) the latency budget. Own measurements support this decision rule: on chains of length 20 resolution generated 231 clauses versus 2.1 million models (about 9,000 times fewer operations); on pigeonhole k = 3 enumeration took 4,096 models versus 59,504 clauses. '
  'Neither method dominates; a practical component would measure m and the Horn fraction and select the method (or fall back to a time-limited run of both).')

# ====================================================================== TASK 3
H('Task 3 - Knowledge Engineering in First-Order Logic: University Exam-Eligibility Advisor', 1)
H('3.1 Knowledge-engineering process', 2)
BUL([('Task: ', 'decide whether student s may write the examination of course c, and produce hall tickets.'),
     ('Knowledge: ', 'minimum attendance 75%, condonation down to 60% with approved leave, prerequisite course passed (pass mark 40), fees paid or scholarship, no disciplinary action.'),
     ('Vocabulary: ', 'constants - students, courses, None; predicates - Student/1, Course/1, Prereq/2, Enrolled/2, Attendance/3, Grade/3, ApprovedLeave/2, FeePaid/1, Scholarship/1, NoDisciplinary/1, AttOK/2, Passed/2, PrereqOK/2, FeesOK/1, Eligible/2, HallTicket/2; built-ins Geq/2, Gt/2; the Skolem function f(c) appears only in A10.'),
     ('General knowledge, instance facts, queries, debugging: ', 'sections 3.2, 3.3, 3.5.')])
H('3.2 FOL axioms - Student A', 2)
TABLE(['Id', 'Axiom', 'Use'], [list(a) for a in T3['axioms']], widths=[1.1, 12.7, 2.7], size=8.5)
P('Axiom A10 is the existential statement (every course has some prerequisite, possibly None); Skolemising gives p = f(c). A10-A12 are integrity constraints. '
  f"Checking A10 and A11 on the instance found {T3['integrity_violations']['A10']} and {T3['integrity_violations']['A11']} violations. The executable rules are A1-A9 (nine definite clauses); negation is avoided by using positive predicates (NoDisciplinary, FeePaid).")
H('3.3 Growth derivation - Student A', 2)
P('Propositional encoding: for each of the s students and c courses the regulations are instantiated. Per (student, course): AttOK from attendance (2 rules), Passed (1), PrereqOK (1), Eligible (1), HallTicket (1) = 6 rules; per student: FeesOK from fee or scholarship (2 rules). '
  'Rule count R_prop(s,c) = 6sc + 2s, so it grows linearly in s and in c, bilinearly in both. The first-order encoding keeps the same nine rules (A1-A9) for every s and c: R_FOL = 9 (constant). Only facts grow, in both encodings, linearly in sc.')
H('3.4 Query suite - Student B', 2)
rows = []
for x in T3['suite_final']:
    exp = ', '.join(x['expected']) if isinstance(x['expected'], list) else ('true' if x['expected'] else 'false')
    act = ', '.join(x['actual']) if isinstance(x['actual'], list) else ('true' if x['actual'] else 'false')
    rows.append([x['type'], x['query'], exp, act, 'pass' if x['passed'] else 'FAIL'])
TABLE(['Type', 'Query', 'Expected', 'Actual', 'Result'], rows, widths=[1.8, 3.8, 4.8, 4.8, 1.3], size=8.5)
P('Instance: nine students (alice ... ian), four courses (CS101, CS201 with prerequisite CS101, CS301 with prerequisite CS201, MA101). Boundary students: carol attends exactly 75%, bob 74%, gina 65% with approved leave, hari 65% without. Expected answers were written by hand before running.')
H('3.5 Defect log', 2)
TABLE(['Id', 'Defect found', 'Symptom in query suite', 'Fix'], [
    ['D1', 'Passed(s,None) was missing, so a course whose prerequisite is None could never satisfy PrereqOK.', 'Every CS101 and MA101 success query failed (6 of 15 queries failed in isolation).', 'Added A4: Student(s) => Passed(s,None).'],
    ['D2', 'Attendance threshold written as strictly greater than 75 (Gt) instead of Geq.', 'Eligible(carol,CS101) failed (the 75% boundary case); 3 of 15 queries failed in isolation.', 'Replaced Gt by Geq in A1.'],
    ['D3', 'The condonation rule did not require ApprovedLeave(s,c).', 'Eligible(bob,CS101) and Eligible(hari,CS101) wrongly succeeded; 4 of 15 failed in isolation.', 'Added ApprovedLeave(s,c) to A2.']], widths=[1, 5.3, 6, 4.2], size=8.5)
rows = [[d['version'], f"{d['passed']}/{d['total']}", '; '.join(d['failed']) if d['failed'] else '-'] for d in T3['defect_log']]
TABLE(['KB version (defects fixed cumulatively)', 'Queries passed', 'Failing queries'], rows, widths=[5.2, 2.3, 9], size=8.5)
P('Interaction between defects: after D1 is fixed the pass count stays at 11 when D2 is fixed, because D3 masks D2 - carol (75%) is still accepted through the unconditioned condonation rule. D2 was only exposed in isolation (D2 alone: carol fails). '
  'This is why a query suite needs boundary cases and why defects were also tested one at a time. The three defects were found by running the suite on the first-draft KB (version v0); the final KB passes 15/15.')
H('3.6 Size and inference-time measurements', 2)
rows = [[r['s'], r['c'], f(r['prop_rules']), r['fol_rules'], f(r['prop_sentences']), f(r['fol_sentences']), f(r['single_total_prop_ms']), f(r['single_total_fol_ms']), f(r['sweep_total_prop_ms'], 1), f(r['sweep_total_fol_ms'], 1), r['fol_query_unifs'], 'yes' if r['agree'] else 'NO'] for r in T3['growth']]
TABLE(['s', 'c', 'Prop rules', 'FOL rules', 'Prop sentences', 'FOL sentences', 'Prop build+1 query ms', 'FOL build+1 query ms', 'Prop build+sweep ms', 'FOL build+sweep ms', 'FOL unifs / query', 'Same answers'], rows, size=7.5)
FIG('task3_growth.png', 'Figure 3.1 - Rule counts and time for the propositional and first-order encodings.', 13.5)
P('Propositional rule counts equal 6sc + 2s exactly (42, 200, 1,300, 6,400, 32,000, 62,000, 186,000). "Sweep" computes eligibility of all (s,c) pairs (propositional forward chaining versus a single first-order backward-chaining query Eligible(?s,?c)); both encodings returned identical eligible sets for every size. '
  'The single-query workload is Eligible for one student/course pair; "build" is the time to construct and index the KB (for the propositional encoding this includes instantiating 6sc + 2s rules).')
H('3.7 Joint conclusion - why expressiveness does not guarantee performance', 2)
P('The first-order encoding is smaller from the start: its rule set stays at nine rules, and total sentences are 42 versus 64 at (s=3, c=2) and 102,975 versus 287,947 at (3,000, 10). '
  'For a single query including KB construction, the propositional encoding is faster for small KBs (0.06 ms versus 0.15 ms at sc = 6; 0.10 versus 0.12 ms at sc = 30) and the first-order encoding becomes faster between sc = 30 and sc = 200 (0.57 versus 0.67 ms at sc = 200; 62.8 versus 868 ms at sc = 30,000), because instantiating 6sc + 2s rules costs more than answering the query by unification. '
  'For full sweeps the propositional encoding is always faster (at sc = 30,000: 1,808 ms versus 6,978 ms, 3.9 times) because each first-order step pays for unification, variable renaming and substitution copying, whereas a ground rule is a hash lookup. '
  'Greater expressiveness therefore buys a compact, general, maintainable KB (constant axioms) but not lower per-inference cost; it pays off when the domain is large or changes (so grounding is wasted) and queries are goal-directed. '
  'For a small fixed KB or a bulk computation over every ground instance, propositional inference is competitive or better.')

# ====================================================================== TASK 4
H('Task 4 - The Reality of Unification and Lifted Inference', 1)
H('4.1 Implementation', 2)
P('Terms: variables begin with "?", compound terms are tuples (functor, args...). The implementation provides UNIFY with a triangular substitution, an optional occurs check, SUBST (full resolution of bindings, which detects cyclic substitutions), idempotent MGU extraction, composition of substitutions, standardising apart by renaming, lifted (generalised) Modus Ponens and propositionalisation over a function-free or depth-bounded Herbrand universe. '
  'The unifier is reused by Tasks 3, 5, 6 and 7.')
H('4.2 Most general unifiers by hand and by program - Student B', 2)
CODE('''1. P(x, f(y)) vs P(a, f(b))
   x = a ; f(y) = f(b) -> y = b                         MGU {x/a, y/b}
2. Knows(John, x) vs Knows(y, Mother(y))
   John = y -> y/John ; x = Mother(y) -> x/Mother(y); apply composition
   MGU {y/John, x/Mother(John)}
3. Q(f(x), g(y)) vs Q(z, g(f(a)))
   f(x) = z -> z/f(x) ; g(y) = g(f(a)) -> y/f(a)        MGU {z/f(x), y/f(a)}
4. P(x, f(x)) vs P(f(y), y)   [occurs check]
   x = f(y) -> x/f(y) ; f(x) = y -> need y/f(x) = f(f(y)) : y occurs in f(f(y))
   FAILS with occurs check
5. Knows(John, x) vs Knows(x, Elizabeth)   [standardise apart]
   as written: x/John then John = Elizabeth: clash -> FAILS (wrongly)
   rename second term: Knows(x1, Elizabeth): x1/John, x/Elizabeth   MGU {x1/John, x/Elizabeth}''')
rows = [[t['pair'], t['mgu'] if t['mgu'] else 'fails', t['no_occurs_check'], t.get('after_standardise_apart', '-')] for t in T4['unifier_tests']]
TABLE(['Pair', 'Program MGU (occurs check on)', 'Occurs check off', 'After standardising apart'], rows, widths=[5.2, 3.8, 4.2, 3.3], size=8)
P(f"Composition: applying {T4['composition']['s1']} then {T4['composition']['s2']} equals the composed substitution {T4['composition']['composed']} (checked: {T4['composition']['check']}). A clash such as P(a,x) vs P(b,y) correctly returns failure.")
P('Answer to the transfer question: if the occurs check is removed, pair 4 is the one that gives a wrong answer - UNIFY returns a binding set although no finite unifier exists, and applying it produces an infinitely deep term (the program detects this as a cyclic substitution). Pair 5 fails without standardising apart even though a unifier exists, so skipping standardisation gives a wrong "no" answer.')
H('4.3 Lifted Modus Ponens - correctness - Student B', 2)
P('Generalised Modus Ponens: if p_i\' unifies with p_i under theta for every premise of a rule p_1 & ... & p_n => q, then SUBST(theta, q) follows. '
  'It is sound because it is Universal Instantiation (instantiate the universally quantified rule with theta, which is valid for every ground instance) followed by ordinary Modus Ponens on the instantiated premises. '
  'Using the most general unifier loses nothing: every other unifier is an instance of it. It avoids ground instances because the rule is instantiated only with the constants that actually occur in matching facts. '
  f"Example: Parent(x,y) & Parent(y,z) => Grandparent(x,z) over three Parent facts derived {', '.join(d['conclusion'] for d in T4['lifted_mp_example'])} with {T4['lifted_mp_unifications']} unifications.")
H('4.4 Ground-clause growth with constants - Student A', 2)
rows = []
for r in T4['growth_constants']:
    rows.append([r['k']] + [f(r['vars%d' % v]) + ('' if r['vars%d_measured' % v] else ' *') for v in (2, 3, 4)] + [f(r['vars3_ms'], 1)])
TABLE(['Constants k', 'Ground instances, rule with 2 variables (k^2)', '3 variables (k^3)', '4 variables (k^4)', 'Time to ground 3-variable rule ms'], rows, size=9)
P('* value from the formula k^4 (generation not run above 200,000 instances); all other entries were counted by generating the instances. The count equals k^v exactly, where v is the number of distinct variables in the rule. '
  'Predicate arity r gives k^r ground atoms: k = 10: 10, 100, 1,000, 10,000, 100,000 for r = 1..5; k = 30: 30, 900, 27,000, 810,000, 24,300,000.')
FIG('task4_growth.png', 'Figure 4.1 - Ground rule instances against the number of constants.', 10)
H('4.5 Function symbols - Student A', 2)
rows = [[r['depth'], r['unary_1const'], r['unary_2const'], f(r['binary_2const']), f(r['rule2vars_instances'])] for r in T4['growth_function']]
TABLE(['Depth bound d', 'Ground terms: one constant, unary f', 'two constants, unary f', 'two constants, unary f and binary g', 'Ground instances of a 2-variable rule (previous column squared)'], rows, size=8.5)
P('With a single unary function the number of terms grows linearly with the depth bound (d + 1 per constant) and the Herbrand universe is infinite, so propositionalisation never terminates without a bound. With a binary function symbol the count roughly squares at each level (2, 8, 74, 5,552, 30,830,258 ...), i.e. doubly exponential in d. '
  'Counts for d <= 3 were verified by enumerating the terms.')
H('4.6 Lifted versus propositional inference on the same query - Student A', 2)
P('KB: a chain of k people with Parent(p_i, p_(i+1)) facts and the rule Parent(x,y) & Parent(y,z) => Gp(x,z). Query: Gp(p0, p2). Lifted = backward chaining with unification; propositional = ground all k^3 instances, index, then backward chain over ground clauses.')
rows = []
for r in T4['lifted_vs_prop']:
    rows.append([r['k'], f(r['ground_rules']), r['lifted_noindex']['goals_expanded'], r['lifted_noindex']['unifications'], r['lifted_indexed']['unifications'], f(r['lifted_indexed']['time_ms'], 3), f(r['prop_grounding_ms'], 1), r['prop_steps'], f(r['prop_query_ms'], 4), r['breakeven_queries'] if r['breakeven_queries'] else 'never'])
TABLE(['k', 'Ground rules', 'Lifted goals', 'Lifted unifs (scan)', 'Lifted unifs (indexed)', 'Lifted time ms', 'Grounding ms', 'Prop steps', 'Prop query ms', 'Break-even #queries'], rows, size=8)
L = T4['lifted_vs_prop']
P(f"Lifted inference needs 3 goals and 3 indexed unifications whatever k is; the propositional approach must first generate k^3 ground rules ({f(L[-1]['ground_rules'])} at k = 30, {f(L[-1]['prop_grounding_ms'],0)} ms). Once grounded, a query costs only 4 steps (about {L[-1]['prop_query_ms']*1000:.0f} microseconds), so propositionalisation pays off only if the KB is queried many times: "
  f"the break-even (grounding time divided by the per-query time saved) is about {L[0]['breakeven_queries']:.0f} queries at k = 5, {L[1]['breakeven_queries']:,.0f} at k = 10, {L[2]['breakeven_queries']:,.0f} at k = 20 and {L[3]['breakeven_queries']:,.0f} at k = 30. "
  "These break-even values are noisy because the per-query times are microseconds, but they grow roughly with the grounding cost, i.e. as k^3: from tens of queries at k = 5 to thousands at k = 30.")
H('4.7 Joint engineering decision', 2)
P('Propositionalise despite lifted inference when (1) the domain is finite and small (function-free, k small) so k^v ground clauses fit in memory - at k = 30, three variables give 27,000 clauses but four give 810,000; (2) the KB is queried many times (break-even in the thousands of queries at k = 30); (3) the KB changes rarely so grounding is amortised; '
  '(4) an off-the-shelf propositional engine (SAT solver, model checker) is needed; or (5) predicate arity and the number of rule variables are low. Do not propositionalise when function symbols are present (infinite or doubly exponential universe), when the constant set grows or changes, or when queries are rare (grounding dominates).')

# ====================================================================== TASK 5
H('Task 5 - Upgrading Resolution from Propositional to First-Order Logic', 1)
H('5.1 Conversion to FOL and CNF - Student A', 2)
P('Statements and predicates: Employee(e), Handled(e,d), Restricted(d), Authorised(e), ContainsPatientData(d), Audited(d). Types are implicit in the predicates.')
CODE('''S1  forall e forall d [ Employee(e) & Handled(e,d) & Restricted(d) => Authorised(e) ]
    eliminate =>:  ~Employee(e) | ~Handled(e,d) | ~Restricted(d) | Authorised(e)
    drop forall:   C1 = { ~Employee(e), ~Handled(e,d), ~Restricted(d), Authorised(e) }

S2  forall d [ ContainsPatientData(d) => Restricted(d) ]
                   C2 = { ~ContainsPatientData(d), Restricted(d) }

S3  exists e [ Employee(e) & forall d ( Audited(d) => Handled(e,d) ) ]
    eliminate =>:  exists e [ Employee(e) & forall d ( ~Audited(d) | Handled(e,d) ) ]
    Skolemise e -> Sk1 (a CONSTANT: exists e is not inside any forall)
                   Employee(Sk1) & forall d ( ~Audited(d) | Handled(Sk1,d) )
    split & drop forall:   C3 = { Employee(Sk1) }
                           C4 = { ~Audited(d), Handled(Sk1,d) }

S4  C5 = { ContainsPatientData(R1) }     C6 = { Audited(R1) }

Goal: exists e Authorised(e).  Negated goal: forall e ~Authorised(e)
                   C7 = { ~Authorised(e) }''')
P('Justification of the Skolem constant: the existential quantifier in S3 is outermost, so the chosen employee does not depend on any document and is a 0-ary Skolem function, i.e. a constant. '
  'If the sentence had meant "for every document some employee handled it" (forall d exists e), the Skolem term would be a function f(d); that is a weaker statement, and the proof below would then fail because different documents could have different employees.')
H('5.2 Proof tree (set-of-support strategy) - Student A', 2)
rows = []
for i, (c, how, par) in enumerate(T5['proof_tree']):
    rows.append([i + 1, c, how if par == [] else how.split(' with')[0] + '  from  [' + ' ; '.join(par[:1]) + ']  and  [' + ' ; '.join(par[1:]) + ']'])
TABLE(['#', 'Clause', 'Derivation'], rows, widths=[0.8, 6.8, 8.9], size=7.5)
P('Compact proof tree: C7 + C1 gives ~Employee(e) | ~Handled(e,d) | ~Restricted(d) [e unified]; with C3 (e/Sk1) gives ~Handled(Sk1,d) | ~Restricted(d); with C4 gives ~Restricted(d) | ~Audited(d); with C2 gives ~Audited(d) | ~ContainsPatientData(d); with C6 (d/R1) gives ~ContainsPatientData(R1); with C5 gives the empty clause. '
  'The witness is Sk1: the authorised employee exists (the proof does not name a real person). Proof length: 6 resolution steps.')
H('5.3 Resolution strategies and measurements - Student B', 2)
P('The prover performs binary resolution with factoring, standardising apart, variant-based duplicate detection and the Task 4 unifier. Strategies: none (breadth-first given-clause loop), unit preference (shortest clause first) and set-of-support (SOS: every resolution uses a clause descended from the negated goal). '
  '"Distractors" adds that many unrelated employees, documents, audits and handling facts (4 clauses each) to show how the strategies scale with irrelevant knowledge.')
rows = [[r['distractors'], r['strategy'], r['clauses_generated'], r['resolution_steps'], r['unification_attempts'], r['proof_length'], f(r['time_ms'], 1)] for r in T5['strategy_comparison']]
TABLE(['Distractors', 'Strategy', 'Clauses generated', 'Resolution steps', 'Unification attempts', 'Proof length', 'Time ms'], rows, size=9)
FIG('task5_strategies.png', 'Figure 5.1 - Clauses generated by each resolution strategy as irrelevant knowledge grows (log scale).', 9.5)
P('With 30 distractors, unit preference generated 257 clauses and set-of-support 2,668, versus 9,670 with no strategy (38 and 3.6 times fewer). The proof length is 6 in all cases except SOS with distractors, where it found a 5-step proof through a distractor employee. '
  'Unit preference works well here because most clauses are facts; SOS is complete and is the more general-purpose restriction.')
H('5.4 Non-entailed queries under a step cap', 2)
rows = []
for r in T5['non_entailed']:
    rows.append([r['query'], r['strategy'], r['clauses_generated'], 'saturated (no proof)' if r['saturated'] else 'cap 400 reached', r['kb_clause_count']])
TABLE(['Query', 'Strategy', 'Clauses generated', 'Outcome', 'Distinct clauses kept'], rows, widths=[6.4, 1.8, 2.4, 3.6, 2.3], size=8)
P('For the function-free KB both strategies terminate: the set of possible clauses over the finite Herbrand universe is finite, so the prover saturates and reports "not entailed". When one axiom introduces a function symbol (Employee(x) => Employee(sup(x))) the universe is infinite: both strategies keep producing new terms sup(sup(...Sk1...)) and stop only at the step cap - even set-of-support, because the negated goal resolves against the ever-growing Employee facts.')
H('5.5 Comparison with the propositional prover of Task 2', 2)
rows = [[r['distractors'], r['domain_size'], r['ground_input_clauses'], r['prop_generated'], r['prop_attempted'], r['prop_proof_len'], r['fol_input_clauses'], r['fol_generated'], r['fol_unif_attempts'], r['fol_proof_len']] for r in T5['prop_vs_fol']]
TABLE(['Distractors', 'Domain size', 'Ground input clauses', 'Prop clauses generated', 'Prop resolvents attempted', 'Prop proof length', 'FOL input clauses', 'FOL clauses generated (SOS)', 'FOL unification attempts', 'FOL proof length'], rows, size=7.5)
P('On the small domain {Sk1, R1} the propositional prover (Task 2 code) needs 13 ground input clauses and generates 60 clauses; the first-order prover starts from 7 clauses and generates 32. With three extra employees and documents (domain size 8) the ground KB has 103 clauses (prop 564 generated) against 19 (FOL 130 generated). '
  'The advantage of lifting is the compact input and fewer generated clauses; its cost is that every resolution step is a unification with renaming (about 0.025 ms per generated clause for the first-order prover against 0.006-0.009 ms for the propositional prover here, i.e. 3-4 times more per clause) and the domain cannot be assumed finite.')
H('5.6 Cross-understanding - Student B', 2)
P('Why Skolemisation preserves satisfiability but not logical equivalence: Skolemisation replaces exists x P(x) by P(c) where c is a new symbol. If the original sentence has a model, extend that model by interpreting c as a witness; the new sentence is then true, so satisfiability is preserved. '
  'The two sentences are not equivalent: P(c) uses a symbol that does not occur in the original, so it is not even a sentence of the original language, and exists x P(x) does not entail P(c) because c could denote a non-witness. '
  'This is enough for resolution refutation because a KB plus negated goal is unsatisfiable if and only if its Skolemised clause form is.')
H('5.7 Cross-understanding - Student A', 2)
P('What the evidence shows about the cost of lifting: lifting shrinks the input (7 clauses against 13 ground clauses at domain size 2; 19 against 103 at size 8) and the number of generated clauses, but each step costs a unification with renaming rather than a hash lookup, and variables create many more-general resolvents that must be compared up to renaming. '
  'The non-entailed query shows that first-order entailment is semi-decidable: if KB |= alpha, a complete strategy will find the empty clause in finite time; if not, with function symbols the search can run forever, so the step cap returns "unknown", not "false". Without function symbols the problem is decidable (finite Herbrand base).')

# ====================================================================== TASK 6
H('Task 6 - Advanced Inference Mini-Investigations', 1)
H('6.1 Knowledge base', 2)
P('Organisation hierarchy: each person has a Manager, a Level (L5 at the root down to L1) and a Dept fact (about 3 facts per person; branching factor 5). Ten definite-clause rules: '
  'Reports (base and right-recursive), Colleague, SeniorLevel (2 rules), CanApprove (2 routes), SameDeptReports, Escalation, Peer. Query: CanApprove(?y, leaf) for the deepest person - who may approve this person\'s requests. '
  'Fact counts: about 100, 1,000 and 10,000 (actual 101, 1,001, 10,001; 34, 334, 3,334 people).')
H('6.2 Forward chaining investigation - Student A', 2)
P('Semi-naive forward chaining to a fixed point: each round joins only against facts new in the previous round, and each complete rule match (firing) is counted once.')
rows = [[r['N'], r['base_facts'], f(r['facts_inferred']), f(r['rule_firings']), r['redundant_derivations'], r['iterations'], r['relevant_derived'], f(r['irrelevant_pct'], 2) + ' %', f(r['time_ms'], 1)] for r in T6['fc']]
TABLE(['Facts (target)', 'Base facts', 'Facts inferred', 'Rule firings', 'Redundant derivations', 'Iterations to fixed point', 'Derived facts relevant to query', 'Irrelevant derived facts', 'Time ms'], rows, size=8)
P('Irrelevant = derived facts that do not appear in the (first) derivation of any answer to the query. Of 60,867 facts inferred at 10,000 base facts, only 13 support the two answers; 99.98 % of the work is irrelevant to the query. '
  'The 30 redundant derivations come from the two CanApprove routes (R6 and R7) that both derive the same direct-manager approvals. When the query concerns only a very small part of the KB, forward chaining still computes the whole closure: its work grows with the KB (515, 5,618, 60,897 firings), not with the query.')
H('6.3 Backward chaining investigation - Student B', 2)
rows = [[r['N'], r['mode'], r['goals_expanded'], r['unifications'], r['max_depth'], r['repeated_subgoals'], r['answers'], f(r['time_ms'], 2)] for r in T6['bc']]
TABLE(['Facts', 'Fact lookup', 'Goals expanded', 'Unifications', 'Max depth', 'Repeated subgoals', 'Answers', 'Time ms'], rows, size=9)
FIG('task6_work.png', 'Figure 6.1 - Work for one query: forward chaining versus backward chaining with and without fact indexing.', 10)
P('Backward chaining expands 26, 32 and 38 goals for 100, 1,000 and 10,000 facts - it grows with the depth of the hierarchy, not with the number of facts. With first-argument indexing the unifications are 33, 41 and 49; without an index every goal scans all facts of its predicate and unifications grow linearly with the KB (587, 7,025, 83,363). '
  '"Repeated subgoals" counts goals that are variants of one already seen (e.g. SeniorLevel(?y) asked for each ancestor).')
H('6.4 Left recursion: non-termination and remedies - Student B', 2)
P('Rule 2 was replaced by the left-recursive Reports(x,z) <= Reports(x,y) & Manager(y,z). Query Reports(leaf, ?z). Four variants were run (goal budget 3,000 for the naive version):')
rows = []
for r in T6['left_recursion']:
    for k, lab in (('naive', 'naive BC'), ('loop_check', 'loop check'), ('depth_bound', 'depth bound'), ('tabling', 'tabling (memoisation)')):
        x = r[k]
        rows.append([r['N'], lab, x['goals_expanded'], x['unifications'], x['max_depth'], x.get('repeated_subgoals', x.get('table_hits', '-')), f"{x['answers']} / {r['correct_answers']}", 'does not terminate' if x.get('non_terminating') else ('complete' if x.get('complete', None) else ('INCOMPLETE' if x.get('complete') is False else 'answers found, then loops'))])
TABLE(['Facts', 'Method', 'Goals expanded', 'Unifications', 'Max depth', 'Repeated subgoals (table hits)', 'Answers / correct', 'Outcome'], rows, size=8)
P('Naive backward chaining expands the subgoal Reports(leaf, ?y\') again at every level, never reaching a different goal: the 3,000-goal budget is exhausted at depth 431-601 (the answers are found early but the search never ends). '
  'Loop check (prune a subgoal that is a variant of an ancestor) terminates after 3 goals but returns only 1 of the correct answers: it is a termination fix that is incomplete for left recursion. '
  'A depth bound equal to the tree depth + 2 is complete here (17-30 goals) but needs a bound chosen from knowledge of the data, and a bound that is too small silently loses answers. '
  'Tabling (memoising answers per variant subgoal and iterating to a fixed point) is complete and terminates with 3-5 goals and 20-44 unifications, at the cost of the answer tables and a few extra iterations (3-5).')
H('6.5 Verification questions', 2)
P('Student B - why the inference direction is central on this KB: the query asks about one person, but the rules have large forward fan-out (Colleague, Peer, Reports closure), so forward chaining derives about 60,000 facts for 13 relevant ones. Backward chaining starts at the goal and touches only the ancestors of the leaf (26-38 goals). '
  'Direction matters because the work is proportional to the part of the KB that is explored in that direction. Forward chaining would win when most derived facts are needed (for example, computing the complete approval table).')
P('Student A - why backward chaining remains efficient with many irrelevant facts: it is goal-directed. A fact is touched only if it unifies with a subgoal that arose from the query. With indexing on the bound argument the lookup cost does not depend on how many other facts exist: unifications rose only from 33 to 49 while the KB grew 100 times. Without an index the scan cost does grow (587 to 83,363), so indexing is part of the answer.')

# ====================================================================== TASK 7
H('Task 7 - Design a Knowledge-Based Reasoning Component: Hospital Medication-Safety Advisor', 1)
H('7.1 Stage 1 - Independent design proposals (retained as written)', 2)
P('Each proposal was written before the students compared designs. (If your own original proposals differ, replace this text with them; the final design does not depend on it.)', italic=True, size=10)
TABLE(['Aspect', 'Student A proposal', 'Student B proposal'], [
    ['Representation', 'Propositional: one symbol per (patient, drug, risk) such as allergic_P12_penicillin', 'First-order: general rules with variables over patients and drugs'],
    ['Vocabulary', 'Symbols generated per patient record', 'Predicates Takes, Allergy, HasCondition, Age, Prescribed, ClassOf, Unsafe'],
    ['Inference', 'Forward chaining to a fixed point after loading each patient', 'Backward chaining from the goal Unsafe(patient, drug, reason)'],
    ['Explanation', 'List of the rules that fired', 'Proof tree of the successful derivation']], widths=[3, 6.8, 6.8], size=9)
H('7.2 Stage 2 - Comparison of the two designs', 2)
TABLE(['', 'Agree / differ', 'Strengths', 'Weaknesses', 'Retained'], [
    ['Knowledge form', 'Both use definite (if-then) rules', 'Linear-time or goal-directed inference, easy for clinicians to read', 'Cannot express disjunction or uncertainty', 'Definite clauses'],
    ['Representation', 'Differ', 'A: no unification, simple. B: 2,000 rules stay general; patients are data', 'A: rules multiply with 50,000 patients (k^3 style growth, Task 4). B: unification overhead', 'First-order (B)'],
    ['Inference', 'Differ', 'A: complete closure. B: touches only relevant rules', 'A: derives every risk for every drug (Task 6: 99.98% irrelevant). B: needs care with recursion', 'Backward chaining (B)'],
    ['Explanation', 'Both give one', 'A: easy trace. B: proof tree shows why', 'A: trace includes unrelated firings', 'Proof tree (B)'],
    ['Idea kept from A', '-', 'Pre-indexing and batch screening by forward chaining for nightly checks', '-', 'Optional batch mode']], widths=[2.4, 2.4, 4.5, 4.9, 2.4], size=8)
H('7.3 Stage 3 - Joint final design', 2)
BUL([('Representation: ', 'function-free first-order definite clauses (Datalog style). Rules are about drugs and conditions; patient records are facts loaded into working memory; the decision is "safe" if no Unsafe proof exists (closed-world assumption).'),
     ('Vocabulary: ', 'Age/2, Minor/1 (precomputed from age), Allergy/2, Takes/2, HasCondition/2, Prescribed/2, ClassOf/2 (ontology), derived TakesClass/2 and Unsafe/3 (patient, drug, reason). Six rule templates: allergy, interaction, condition, paediatric, class interaction, triple (drug + condition).'),
     ('Inference: ', 'backward chaining with substitutions (the Task 4 unifier, Task 6 engine) on goal Unsafe(patient, drug, ?reason), asking for all answers.'),
     ('Indexing for scale: ', 'rules are indexed by (predicate, constant in the drug argument), so a query inspects only the rules for the prescribed drug; facts are indexed on their first two arguments (patient id), so a patient record is found without scanning the 50,000-patient fact base.'),
     ('Explanation: ', 'the first successful proof tree is printed; its size is the explanation length. The reason constants (R<k>) identify the rule that fired.')])
CODE('''ADVISE(patient, drug):
    load facts of patient into working memory; add Prescribed(patient, drug)
    reasons <- BC-ASK( Unsafe(patient, drug, ?r) )            # all answers
    if reasons is empty: return SAFE
    tree <- first proof tree of Unsafe(patient, drug, ?r)
    return UNSAFE, reasons, EXPLAIN(tree)

BC-SOLVE(goals, theta, depth):
    if goals is empty: yield theta
    g <- SUBST(theta, first(goals))
    for fact in FACT-INDEX[pred(g), bound arguments of g]:          # indexed lookup
        theta2 <- UNIFY(g, fact, theta); if theta2: yield from BC-SOLVE(rest, theta2, depth)
    for rule in RULE-INDEX[pred(g), drug constant of g]:           # drug-keyed rules + rules with variable
        (head, body) <- STANDARDISE-APART(rule)
        theta2 <- UNIFY(g, head, theta)
        if theta2: yield from BC-SOLVE(body + rest, theta2, depth + 1)

EXPLAIN(tree): print each node as  goal  [fact | rule]  indented by depth''')
H('7.4 Stage 4A - Theoretical validation - Student A', 2)
BUL([('Soundness: ', 'every answer is derived by Modus Ponens on instantiated rules (lifted MP, Task 4), so each reported reason is entailed by the KB.'),
     ('Completeness: ', 'backward chaining (SLD resolution) is complete for definite clauses with a fair search. The rules here are non-recursive (the only derived predicate, TakesClass, depends on base facts), so the proof tree is bounded and the search terminates; with recursive rules left recursion would need tabling (Task 6).'),
     ('Complexity of one query as a function of KB size: ', 'with the drug-keyed index the number of candidate rules is about R/|D| (R rules, |D| = 60 drugs), each with a body of at most 3 atoms, so steps = c0 + c1 * R/|D|. Measured: 7, 34 and 151 steps at 40, 400, 2,000 rules - 4.4 steps per rule in the drug bucket (151 - 34 = 117 steps for 1,600 more rules = 0.073 per rule). Without the rule index every Unsafe rule head is tried: O(R); measured 56, 473, 2,291 (about 1.1 per rule). Forward chaining matches every rule: O(R) too (125, 709, 3,371).'),
     ('Effect of restricting to definite clauses: ', 'entailment for general propositional KBs is co-NP-complete (model checking / resolution may blow up, Task 2), but for definite clauses it is solved in linear time in the KB size (forward chaining, Task 3) and for function-free first-order definite clauses (Datalog) it is polynomial in the size of the data. The price is expressiveness: no disjunction ("allergic to A or B"), no negation in rule bodies, no uncertainty.')])
H('7.5 Stage 4B - Experimental validation - Student B', 2)
P(f"The test set has {T7['n_cases']} cases: 12 core dangerous combinations triggered by rules among the first 40, 8 by rules 40-399, 6 by rules 400-1,999, 4 multi-reason cases (two independent hazards for the same drug) and 4 random safe prescriptions. "
  'Expected outputs were computed by an independent imperative oracle that reads the rule specifications directly and does not use the logic engine. KB sizes are nested prefixes of one 2,000-rule list (40, 400, 2,000 rules; 2,000-rule mix: 383 allergy, 671 interaction, 374 condition, 57 paediatric, 267 class, 247 triple rules, plus one derived rule).')
rows = []
for s in T7['sizes']:
    rows.append([s['size'], f"{s['correct_bc']}/{s['cases']}", s['unsafe_cases'], f(s['bc_steps'], 1), f(s['bc_latency_ms'], 3), f(s['unindexed_steps'], 1), f(s['unindexed_latency_ms'], 3), f(s['fc_steps'], 1), f(s['fc_latency_ms'], 3), f(s['explanation_nodes'], 2), s['max_explanation_nodes'], f(s['kb_memory_kib'], 1), f(s['query_peak_kib'], 1)])
TABLE(['Rules', 'Correct (indexed BC)', 'Cases flagged unsafe', 'BC steps', 'BC latency ms', 'Unindexed BC steps', 'Unindexed latency ms', 'FC steps', 'FC latency ms', 'Mean explanation nodes', 'Max expl. nodes', 'KB memory KiB', 'Query peak KiB'], rows, size=7)
FIG('task7_steps.png', 'Figure 7.1 - Inference steps per query as the KB grows from 40 to 2,000 rules.', 10)
S = T7['scale']
P(f"All three engines agreed with the oracle on all {T7['n_cases']} cases at every size. Baselines: unindexed backward chaining (linear scan of rules and facts) and forward chaining to a fixed point per patient. At 2,000 rules the design needs 151 steps (0.53 ms) against 2,291 steps (10.2 ms) for the unindexed engine and 3,371 steps (4.1 ms) for forward chaining: 15 and 22 times fewer steps. "
  f"Scale test: {S['patients']:,} patients ({S['facts']:,} facts) and 2,000 rules in one fact base: built in {S['build_s']} s, {S['memory_mib']} MiB; all {S['cases']} cases correct; mean latency {S['mean_latency_ms']} ms, maximum {S['max_latency_ms']} ms, mean {S['mean_steps']} steps - the same as with one patient in memory, as predicted by the index. "
  f"One query with no index on the same data needed {S['unindexed_one_query_steps']:,} unifications ({S['unindexed_one_query_ms']/1000:.1f} s).")
P('Observations: (i) the number of cases flagged unsafe rises from 17 (40 rules) to 25 (400) and 30 (2,000): the same patients receive different verdicts as the KB grows, so the advisor is only as safe as its rule coverage; (ii) explanation length is small (mean 1.7-2.9, maximum 5 nodes) because rules are shallow; '
  '(iii) memory is dominated by the facts (82.6 MiB for 355,950 facts) rather than by 2,000 rules (648 KiB). One example explanation (2,000-rule KB):')
CODE('\n'.join(T7['explanation_example']['lines']))
P('Reading: patient T1 is prescribed D35 and also takes D34; rule R26 states that this combination is unsafe.')
H('7.6 Stage 5 - Cross-defence', 2)
P('Student A explains the experimental evidence for the design: indexed backward chaining was the only configuration whose steps stayed small as rules grew (151 versus 2,291 and 3,371 at 2,000 rules) and whose latency stayed flat at 50,000 patients (0.64 ms mean), and it agreed with the oracle on every case.')
P('Student B explains why the theoretical result applies: the complexity result says one query costs O(R/|D|) because the index restricts the rules to the prescribed drug, and the rule bodies have at most three atoms with the patient bound, so the measured 7 -> 34 -> 151 steps follow c0 + c1 * R/|D|; the definite-clause restriction is what makes goal-directed search complete and polynomial.')
H('7.7 Stage 6 - Joint evaluation', 2)
BUL([('Why the problem suits a logical agent: ', 'the knowledge is mostly explicit if-then rules written by clinicians and pharmacists; decisions must be explained and audited (a proof tree is the explanation); rules change often and are added without retraining; correctness can be tested case by case.'),
     ('Limits of the representation: ', 'uncertainty (no probabilities for likelihood or severity), incomplete data (a missing allergy record is treated as "no allergy" under the closed-world assumption - the advisor cannot say "unknown"), conflicting or overlapping rules, dose and timing information, and rule coverage (17 of 34 cases flagged at 40 rules versus 30 at 2,000).'),
     ('What a designer should check before choosing a knowledge-based approach: ', 'is the knowledge expressible as definite rules; is it stable and authoritative enough to encode; how complete is the input data; is explanation or audit required; what are the KB size, query rate and latency budget (measure steps with the intended index); how will the rules be validated and kept consistent; and is a fallback needed for "unknown" cases (human review).')])

# ====================================================================== CONTRIBUTION RECORD
H('CONTRIBUTION RECORD', 1)
TABLE(['Task', 'Student A - primary contribution', 'Student B - primary contribution', 'Joint work'], [
    ['Task 1', 'Symbol/sentence counts, 2^m models, relevant symbols, soundness and completeness of model checking; inference-rule derivation and step counts', 'Checker instrumentation, n = 2, 3, 4 experiments, three query types; soundness truth tables and "not derived is not false"', 'Wumpus KB, entailment checker'],
    ['Task 2', 'Manual CNF, resolution proof, clause statistics for chains, non-entailed termination', 'Model-checking measurements, KB families where each method wins', 'Both implementations, policy KB, joint design question'],
    ['Task 3', 'FOL vocabulary and 12 axioms, growth derivation', '15-query suite, defect log, size/time measurements', 'Two encodings, conclusion'],
    ['Task 4', 'Ground-clause growth, function-symbol growth, lifted vs propositional comparison', 'Hand-derived MGUs, occurs check, soundness of lifted inference', 'UNIFY, lifted MP, propositionalisation, engineering decision'],
    ['Task 5', 'Conversion, Skolemisation, proof tree, strategy implementation', 'Strategy comparison, non-entailed query, comparison with Task 2 prover', 'Prover design'],
    ['Task 6', 'Forward chaining engine and metrics', 'Backward chaining engine, left recursion and remedies', 'Organisation KB'],
    ['Task 7', 'Stage 1 proposal A, theoretical validation, cross-defence', 'Stage 1 proposal B, 34 test cases and experiments, cross-defence', 'Stages 2, 3 and 6']], widths=[1.4, 5.4, 5.4, 4.4], size=8.5)

# ====================================================================== CONCLUSION etc.
H('Conclusion', 1)
P('The experiments show that the choice of reasoning method depends on the structure of the knowledge base and the operating requirement, not on a single "best" algorithm. '
  'Model checking is simple and complete but costs 2^m; relevant-symbol restriction made the Wumpus queries tractable and inference rules answered them with 3-10 steps. '
  'Resolution beat enumeration on implication chains by orders of magnitude but lost badly on the pigeonhole family. '
  'First-order encodings kept the exam-eligibility rules constant at nine instead of 6sc + 2s, yet did not make individual inferences cheaper. '
  'Unification enabled lifted inference whose cost is independent of the number of constants, whereas propositionalisation costs k^v ground clauses and pays off only after thousands of repeated queries. '
  'First-order resolution proved the existence of an authorised employee in six steps with a Skolem constant; set-of-support and unit preference cut generated clauses by factors of 3.6 to 38 when irrelevant knowledge was present, and function symbols make non-entailment undetectable without a step cap. '
  'Backward chaining touched 26-38 goals regardless of KB size, forward chaining computed 60,867 facts of which 13 mattered, and left recursion required tabling to stay both terminating and complete. '
  'In the medication-safety design, indexed backward chaining over definite clauses was correct on all 34 cases, flat in latency at 50,000 patients, and 15-22 times cheaper than the baselines at 2,000 rules - with the caveat that the closed-world assumption and rule coverage bound its safety.')
H('References', 1)
for r in ['Russell, S. and Norvig, P., Artificial Intelligence: A Modern Approach, 4th Edition, Pearson, 2021 (Chapters 7-9).',
          'Robinson, J. A., A Machine-Oriented Logic Based on the Resolution Principle, Journal of the ACM, 12(1), 1965.',
          'Dowling, W. F. and Gallier, J. H., Linear-time algorithms for testing the satisfiability of propositional Horn formulae, Journal of Logic Programming, 1(3), 1984.',
          'Haken, A., The intractability of resolution, Theoretical Computer Science, 39, 1985.',
          'Python Software Foundation, Python 3 Documentation: itertools, collections, time, tracemalloc.']:
    doc.add_paragraph(r, style='List Number')

H('APPENDIX A - IMPLEMENTATION AND EXECUTION DETAILS', 1)
CODE('''CSA1717_CO3_Assignment3/
+-- src/
|   +-- assignment3_co3.py
+-- results/
|   +-- results.json
|   +-- summary.csv
|   +-- execution_output.txt
+-- evidence/
    +-- task1_models.png   task2_chain.png   task2_php.png
    +-- task3_growth.png   task4_growth.png  task5_strategies.png
    +-- task6_work.png     task7_steps.png''')
CODE('python --version\nPYTHONHASHSEED=0 python src/assignment3_co3.py --out results              # all tasks (about 35 s)\nPYTHONHASHSEED=0 python src/assignment3_co3.py --out results --only 4 5 # selected tasks')
P('Main components in the source file: propositional library (expressions, truth tables, CNF, instrumented resolution); Wumpus KB and Derivation checker (Task 1); policy and KB families (Task 2); FOL library (UNIFY, SUBST, composition, standardise apart, lifted MP, Herbrand terms, backward chaining engine, proof trees); exam KB and propositional encoder (Task 3); Task 4 experiments; first-order resolution prover with strategies (Task 5); forward chaining and tabling engines (Task 6); medication KB generator, oracle, test cases and scale test (Task 7).')
H('A.1 Interpretation of measured values', 2)
P('Models enumerated, sentence evaluations, clauses generated, resolvents attempted, tautologies discarded, subsumed clauses removed, unification attempts, goals expanded, rule firings and inference steps are operation counts. Execution time is supplementary and machine dependent. Memory is measured with tracemalloc (Python allocations only).')

H('APPENDIX B - CAPTURED EXECUTION OUTPUT', 1)
CODE(open(os.path.join(BASE, 'results/execution_output.txt')).read())
P('Machine-readable results for every table above are stored in results/results.json and results/summary.csv.')

H('APPENDIX C - ASSUMPTIONS AND LIMITATIONS', 1)
BUL(['Wumpus: restricted-symbol KBs omit the at-least-one-wumpus sentence; the "neither" verdicts were validated against the full KB for n = 2 and by exhibiting two extensions for n = 3, 4. Time projections for infeasible runs use the best measured throughput (an optimistic bound).',
     'Resolution counts depend on the clause-selection order; pigeonhole runs for k >= 4 are capped at 60,000 generated clauses, so "cap reached" means unfinished, not failed.',
     'Exam eligibility: negation is avoided by positive predicates (closed-world facts such as NoDisciplinary); the propositional encoding receives pre-computed attendance flags, which favours it in time comparisons. The three defects were seeded in the first-draft KB and found by the query suite; they are realistic mistakes, not accidents.',
     'Lifted-versus-propositional timings are for one small KB shape (chain with a 3-variable rule); break-even values scale with k^3 for this rule.',
     'First-order resolution does not implement subsumption or paramodulation; the step cap is a pragmatic stop, not a decision procedure.',
     'Organisation KB: a balanced tree with branching factor 5; irrelevance is measured on first derivations.',
     'Medication KB: rules are synthetic (generated from templates), not clinical guidance; the closed-world assumption treats missing records as absence; the test oracle shares the rule specifications with the engine, so it validates inference but not rule content.',
     'Execution times depend on the machine; operation counts are the primary basis for comparison.'])
H('APPENDIX D - SOURCE FILES', 1)
P('The accompanying ZIP contains src/assignment3_co3.py, results/ and evidence/. The source is intended for academic demonstration and runs with the command in Appendix A.')
P('')
P('Student Signatures:', bold=True)
P('Student A: ______________________      Student B: ______________________')

doc.save(os.path.join(BASE, 'CSA1717_Assignment3_CO3_Report.docx'))
print('saved')
